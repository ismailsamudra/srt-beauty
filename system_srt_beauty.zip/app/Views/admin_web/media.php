<!-- TOP NAVIGASI START -->
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <small>
            <?php btback() ?>
            <a href="" style="color: <?= color('primary-b') ?>;">
                <strong>
                    <i class="fa fa-globe mr-2"></i> <?= strtoupper(str_replace('/', ' ', XURI)) ?>
                </strong>
            </a>
            <a href="javascript:void(0);" onclick="$('#dguser').datagrid('reload');" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
        </small>
    </center>
</div>
<!-- TOP NAVIGASI END -->
<!-- BODY START -->
<input type="hidden" id="idx">
<div class="row m-2">
    <div class="col-md-9 mb-2 mt-2 table-responsive">
        <div class="row">

            <div class="col-12" id="fo1">
                <center>
                    <table id="dguser" toolbar="" class="easyui-datagrid" singleSelect="true" style="width: 100%;" fitColumns="true" rowNumbers="true" pagination="false" url="<?= XROOT ?>admin_web/get_media" pageSize="10" pageList="[10,25,50,75,100,125,150,200]">
                        <thead>
                            <tr>
                                <th field="pur_res" width="100%" formatter="show_res"></th>
                            </tr>
                        </thead>
                    </table>
                </center>
            </div>

        </div>

    </div>
    <div class="col-md-3 mb-2 mt-2 table-responsive">
        <div class="container">
            <div class="">
                <strong>
                    M-BOOK :
                </strong>
                <hr>
                Doubel Klick pada baris data Untuk Edit
                <hr>
                Kosongkan Url jika tidak ingin menampilkan di website
                <hr>
                <a href="https://www.embedmymap.com/" target="_blank">API Google Map</a>
                <hr>
            </div>
            <br>
        </div>
        <center>
            <i class="fa fa-globe fa-5x"></i><br>
            <strong>
                <?= strtoupper(str_replace('/', ' ', XURI)) ?>
            </strong><br>
        </center>
    </div>
</div>
<!-- BODY END -->
<!-- Start Modal 1 -->
<div class="modal fade" id="edit" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="_user"><i class="fa fa-edit mr-2"></i>Edit</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <form id="fm" method="post" enctype="multipart/form-data">
                    <small>Nama Media</small>
                    <input type="text" class="form-control" name="id" id="id" readonly>
                    <small>URL : Optional</small>
                    <textarea name="code" id="code" cols="30" rows="4" class="form-control"></textarea>
                </form>

            </div>
            <div class="modal-footer">
                <a href="javascript:void(0);" onclick="save();" class="btn btn-outline-dark btn-sm"><i class="fa fa-save mr-2"></i>Save</a>
            </div>

        </div>
    </div>
</div>
<!-- End Modal 1-->
<script type="text/javascript">
    //-----------------------------------------start
    function show_res(val, row) {
        for (var name in row) {
            var t = `
            <div class="card col table-responsive my-1">
                <div class="row my-1">
                    <div class="col-md-12">
                        <strong><u>` + row.id + `</u></strong>
                    </div>
                    <div class="col-md-12">
                    <textarea cols="30" rows="2" class="form-control" readonly>` + row.code + `</textarea>
                    </div>
                </div>
            </div>
            `;
            if (row["pur_res"] == "Received") {} else {
                return t;
            }
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function edit() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $('#fm').form('load', row);
            $('#edit').modal('show');
        } else {
            msg('Error', 'Klick Sekali Lagi');
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function save() {
        $('#fm').form('submit', {
            url: '<?= XROOT ?>admin_web/save_media',
            onSubmit: function() {
                return $(this).form('validate');
            },
            success: function(result) {
                var result = eval('(' + result + ')');
                if (result.success) {
                    $('#edit').modal('hide');
                    $('#dguser').datagrid('reload');
                    msg('Success !', 'Berhasil di update');
                } else {
                    msg('Error', result.errorMsg);
                }
            }
        });
    }
    //-----------------------------------------end
    //-----------------------------------------start
    $(function() {
        $('#dguser').datagrid({
            singleSelect: true,
            onDblClickRow: function() {
                edit();
            }
        })

    })
    //-----------------------------------------end
</script>