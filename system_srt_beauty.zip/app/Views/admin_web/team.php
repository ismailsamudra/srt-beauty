<link rel="stylesheet" href="<?= XROOT ?>script/summernote/summernote-bs4.min.css">
<script src="<?= XROOT ?>script/summernote/summernote-bs4.min.js"></script>
<link rel="stylesheet" href="<?= XROOT ?>script/crop/croppie.css">
<!-- TOP NAVIGASI START -->
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <small>
            <?php btback() ?>
            <a id="btnadd"></a>
            <a href="" style="color: <?= color('primary-b') ?>;">
                <strong>
                    <i class="fa fa-globe mr-2"></i> <?= strtoupper(str_replace('/', ' ', XURI)) ?>
                </strong>
            </a>
            <a href="javascript:void(0);" onclick="$('#dguser').datagrid('reload');" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
        </small>
    </center>
</div>
<!-- TOP NAVIGASI END -->
<!-- BODY START -->
<input type="hidden" id="idx">
<div class="row m-2">
    <div class="col-md-9 mb-2 mt-2 table-responsive">
        <div class="row">

            <div class="col-12" id="fo1">
                <center>
                    <table id="dguser" toolbar="" class="easyui-datagrid" singleSelect="true" style="width: 100%;" fitColumns="false" rowNumbers="false" pagination="true" url="<?= XROOT ?>admin_web/get_team" pageSize="10" pageList="[10,25,50,75,100,125,150,200]">
                        <thead>
                            <tr>
                                <th field="id" width="100%" formatter="show_res" sortable="true"></th>
                            </tr>
                        </thead>
                    </table>
                </center>
            </div>
            <div class="col-12" id="fo2">
                <div class="card col bg-1 mb-2">
                    <x>
                        <div id="head"></div>
                        <a href="javascript:void(0);" onclick="hid()" class="float-right pri-b mx-1" title="Close"><i class="fa fa-times"></i></a>
                        <a href="javascript:void(0)" onclick="save();" class="pri-b float-right mx-1" title="Save"><i class="fa fa-save"></i></a>
                    </x>
                </div>
                <?php $user = db('users')->get()->getResult(); ?>
                <form id="fm" method="post" enctype="multipart/form-data">
                    <input type="hidden" id="id" name="id">
                    <div class="card col my-1">
                        <div class="row mt-2">
                            <div class="col-md-3">
                                <small><strong>TYPE INPUT</strong></small>
                            </div>
                            <div class="col-md-3 mb-2" id="coltype1">
                                <input type="radio" onclick="ckType();" class="mr-2" id="type1" name="type" value="BARU">BARU
                            </div>
                            <div class="col-md-3 mb-2" id="coltype2">
                                <input type="radio" onclick="ckType();" class="mr-2" id="type2" name="type" value="USERS">USERS
                            </div>
                        </div>
                        <div id="iuser" class="my-2">
                            <small><strong>Cari Users</strong></small><br>
                            <select name="user" id="user" class="easyui-combobox" style="width: 300px;">
                                <?php foreach ($user as $o) : ?>
                                    <option value='<?= $o->id ?>'><?= $o->nama ?></option>
                                <?php endforeach ?>
                            </select>
                        </div>
                        <div class="row">
                            <div class="col-md-2">
                                <div id="disp_foto"></div>
                            </div>
                            <div class="col-md-10">
                                <div class="row">
                                    <div class="col-12">
                                        <small><strong>NAMA</strong></small>
                                    </div>
                                    <div class="col-12 mb-2">
                                        <input type="text" class="form-control" placeholder="Input NAMA.." style="height: 24px;" id="nama" name="nama">
                                    </div>
                                </div>
                                <div class="row my-2">
                                    <div class="col-md-3">
                                        <small><strong>JENIS KELAMIN</strong></small>
                                    </div>
                                    <div class="col-md-3 mb-2" id="coljk1">
                                        <input type="radio" onclick="ckJk();" class="mr-2" id="jk1" name="jk" value="L"><strong id="ljk1">Laki-Laki</strong>
                                    </div>
                                    <div class="col-md-3 mb-2" id="coljk2">
                                        <input type="radio" onclick="ckJk();" class="mr-2" id="jk2" name="jk" value="P"><strong id="ljk2">Perempuan</strong>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <small><strong>JABATAN</strong></small>
                                    </div>
                                    <div class="col-12">
                                        <input type="url" class="form-control" placeholder="Input jabatan.." style="height: 24px;" id="jabatan" name="jabatan">
                                    </div>
                                </div>
                                <small><strong>DESKRIPSI : Optional</strong></small>
                                <textarea name="desk" id="desk" cols="30" rows="3" class="form-control mb-2"></textarea>
                            </div>

                        </div>
                    </div>
                </form>
                <div class="card col bg-1 mb-2">
                </div>
            </div>
            <div class="col-12" id="fo3">
                <div class="card col bg-1 mb-2">
                    <x>
                        <div id="head2"></div>
                        <a href="javascript:void(0);" onclick="hid()" class="float-right pri-b mx-1" title="Close"><i class="fa fa-times"></i></a>
                        <a href="javascript:void(0)" onclick="crop();" class="pri-b float-right mx-1" title="Save"><i class="fa fa-save"></i></a>
                    </x>
                </div>
                <form id="fm2" method="post" enctype="multipart/form-data">
                    <img id="temp_foto" name="img"></img>
                </form>
            </div>
        </div>

    </div>
    <div class="col-md-3 mb-2 mt-2 table-responsive">
        <div class="container">
            <div class="">
                <strong>
                    M-BOOK :
                </strong>
                <hr>
                Doubel Klick pada baris data Untuk Edit Data
                <hr>
                Untuk Menu Lain Klick Kanan jika desktop dan sentuh tahan jika HP.
                <hr>
                Tombol Save Berada Pada Kolom Kanan Atas di samping tombol close
                <hr>
                Kusus Type input BARU, Upload foto berada di Menu Klick kanan.
                <hr>
            </div>
            <br>
        </div>
        <center>
            <i class="fa fa-globe fa-5x"></i><br>
            <strong>
                <?= strtoupper(str_replace('/', ' ', XURI)) ?>
            </strong><br>
        </center>
    </div>
</div>
<!-- BODY END -->
<style>
    .consta>input {
        display: none;
    }
</style>
<!-- KLICK KANAN START -->
<div id="mm" class="easyui-menu">
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="edit();"><i class="fa fa-edit mr-2"></i>Edit</a>
    <!-- <span class=""> -->
    <label for="thumbnail" class="consta" id="lbtumb">
        <a class="btn-sm form-control" plain="true"><i class="fa fa-image mr-2"></i>
            Ganti Foto
        </a>
        <input type="file" name="thumbnail" id="thumbnail" onchange="thumbnail();" accept="image/*">
    </label>
    <!-- </span> -->
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="change_status();"><span id="btn-status"></span></a>
    <a href="javascript:void(0)" class="btn-sm form-control" plain="true" onClick="destroyuser();"><i class="fa fa-trash mr-2 text-danger"></i> Hapus</a>
</div>
<!-- KLICK KANAN END -->
<?php
$web_team = db('web_team')->groupBy('user')->get()->getResult();
foreach ($web_team as $o) {
    // echo $o->user;
    if ($o->user != null) {
        $x = db('users')->getWhere(['id' => $o->user], 1)->getRow();
        echo '
        <input type="hidden" id="nama_' . $x->id . '" value="' . $x->nama . '">
        <input type="hidden" id="foto_' . $x->id . '" value="' . $x->foto . '">
        <input type="hidden" id="jk_' . $x->id . '" value="' . $x->jk . '">
        ';
    }
}
?>
<!---------------------------croppie start--------------------------------->
<script src="<?= XROOT ?>script/crop/croppie.min.js"></script>
<!---------------------------croppie end----------------------------------->
<script type="text/javascript">
    $('#btnadd').html('<a href="javascript:void(0);" onclick="add();" class="btn-sm bt-1 float-left" title="TAMBAH"><i class="fa fa-plus"></i></a>');
    $('#fo2').hide();
    $('#fo3').hide();
    $('#fo1').show();
    //-----------------------------------------start
    function hid() {
        $('#fm').form('clear');
        $('#dguser').datagrid('reload');
        $('#temp_foto').croppie('destroy');
        $('#disp_foto').html('');
        $('#fo2').hide();
        $('#fo3').hide();
        $('#fo1').show();
        $("#coltype1").show();
        $("#coltype2").show();
        $("#coljk1").show();
        $("#coljk2").show();
        document.getElementById('nama').disabled = false;
        $('#btnadd').html('<a href="javascript:void(0);" onclick="add();" class="btn-sm bt-1 float-left" title="TAMBAH"><i class="fa fa-plus"></i></a>');
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function ckType() {
        var id = document.getElementById('id').value;
        if (id == 'insert') {
            if (document.getElementById('type1').checked) {
                document.getElementById('jk1').checked = true;
                document.getElementById('nama').disabled = false;
                $('#disp_foto').html('<center>FOTO<br><img src="<?= XROOT ?>img/avatar/L2.png" width="100%"></center>');
                $('#iuser').hide();
                $('#nama').val('');
                $("#coljk1").show();
                $("#coljk2").show();
            } else {
                $('#iuser').show();
                document.getElementById('nama').disabled = true;
            }
            $('#jabatan').val('');
            $('#desk').val('');
        } else {
            document.getElementById('nama').disabled = false;
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function ckJk() {
        var id = document.getElementById('id').value;
        if (id == 'insert') {
            if (document.getElementById('type1').checked) {
                if (document.getElementById('jk1').checked) {
                    $('#disp_foto').html('<center>FOTO<br><img src="<?= XROOT ?>img/avatar/L2.png" width="100%"></center>');
                } else {
                    $('#disp_foto').html('<center>FOTO<br><img src="<?= XROOT ?>img/avatar/P2.png" width="100%"></center>');
                }
            }
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    $('#user').combobox({
        onChange: function(value) {
            $.post("<?= XROOT ?>admin_web/get_team_us", {
                id: value
            }, function(r) {
                if (r.nama) {
                    foto = (r.foto == '') ? r.jk + '2.png' : r.foto;
                    if (r.jk == 'L') {
                        $("#coljk2").hide();
                        $("#coljk1").show();
                        document.getElementById('jk1').checked = true;
                    } else {
                        $("#coljk1").hide();
                        $("#coljk2").show();
                        document.getElementById('jk2').checked = true;
                    }
                    document.getElementById('nama').disabled = true;
                    $('#nama').val(r.nama);
                    $('#disp_foto').html('<center>FOTO<br><img src="<?= XROOT ?>img/avatar/' + foto + '" width="100%"></center>');
                } else {
                    msg('Error', r.errorMsg);
                }
            }, 'json');
        }
    });
    //-----------------------------------------end
    $('#content').summernote({
        height: 300,
        // themes:paper,
        airMode: false
    })
    //-----------------------------------------start
    function show_res(val, row) {
        for (var name in row) {
            status = (row.status == 'true') ? 'YA' : 'TIDAK';
            if (row.type == 'BARU') {
                nama = row.nama;
                foto = (row.foto == '') ? row.jk + '2.png' : row.foto;
            } else {
                nama = document.getElementById('nama_' + row.user).value;
                jk = document.getElementById('jk_' + row.user).value;
                ft = document.getElementById('foto_' + row.user).value;
                foto = (ft == '') ? jk + '2.png' : ft;
            }
            var t = `
            <div class="card col table-responsive my-1">
                <div class="row mt-1">
                    <div class="col-md-2 col-6">
                       <img src="<?= XROOT ?>img/avatar/` + foto + `" width="100%">
                    </div>
                    <div class="col-md-10 col-12">
                        <div class="row">
                            <div class="col-md-2 col-6">
                                <small>Tampikan Di Web</small>
                            </div>
                            <div class="col-md-10 col-6">
                            <strong>: ` + status + `</strong>  
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2 col-6">
                                <small>NAMA</small>
                            </div>
                            <div class="col-md-10 col-6">
                            <strong>: ` + nama + ` </strong>  
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2 col-6">
                                <small>JABATAN</small>
                            </div>
                            <div class="col-md-10 col-6">
                            <strong>: ` + row.jabatan + `</strong>  
                            </div>
                        </div>
                        <div class="row mb-1">
                            <div class="col-md-2">
                                <small>DESKRIPSI</small><br>
                                <small>[ Type : ` + row.type + ` ]</small>
                            </div>
                            <div class="col-md-10">
                            <textarea cols="30" rows="2" class="form-control iwhite" readonly>` + row.desk + `</textarea> 
                            </div>
                        </div>
                    </div>
                    
                </div>
               
            </div>
            `;
            if (row["id"] == "Received") {} else {
                return t;
            }
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function add() {
        $('#fm').form('clear');
        $('#coltype1').show();
        $('#coltype2').show();
        $('#iuser').hide();
        $('#fo1').hide();
        $('#fo3').hide();
        $('#fo2').show();
        $('#btnadd').html('');
        document.getElementById('type1').checked = true;
        document.getElementById('jk1').checked = true;
        $('#disp_foto').html('<center>FOTO<br><img src="<?= XROOT ?>img/avatar/L2.png" width="100%"></center>');
        $("#head").html('<small class="float-left"><i class="fa fa-plus mr-2"></i>Tambah Data</small>')
        document.getElementById("id").value = 'insert';
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function edit() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $('#fm').form('load', row);
            if (row.type == 'USERS') {
                $('#coltype1').hide();
                $('#coltype2').show();
            } else {
                foto = (row.foto == '') ? row.jk + '2.png' : row.foto;
                $('#coltype2').hide();
                $('#coltype1').show();
                $('#disp_foto').html('<center>FOTO<br><img src="<?= XROOT ?>img/avatar/' + foto + '" width="100%"></center>');
            }
            ckType();
            $('#iuser').hide();
            $('#fo1').hide();
            $('#fo3').hide();
            $('#fo2').show();
            $('#btnadd').html('');
            $("#head").html('<small class="float-left"><i class="fa fa-edit mr-2"></i>Edit Data</small>');
        } else {
            msg('Error', 'Data tidak di pilih');
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function change_status() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $.messager.confirm('Attention!', '<strong class="text-danger">Hati-hati Melakukan aksi ini,</strong><br> Apakah Anda Yakin Ingin Merubah Status data ini ?<br>NAMA : ' + row.nama, function(r) {
                if (r) {
                    $.post("<?= XROOT ?>admin_web/status_team", {
                        id: row.id
                    }, function(result) {
                        if (result.success) {
                            $('#dguser').datagrid('reload');
                            msg('Success !', 'Status Berhasil Di Ubah');
                        } else {
                            msg('Error', result.errorMsg);
                        }
                    }, 'json');
                }
            });
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function destroyuser() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $.messager.confirm('Attention!', '<strong class="text-danger">Hati-hati Melakukan aksi ini,</strong><br> Apakah Anda Yakin Ingin Menghapus data ini ?<br>NAMA : ' + row.nama, function(r) {
                if (r) {
                    $.post("<?= XROOT ?>admin_web/del_team", {
                        id: row.id
                    }, function(result) {
                        if (result.success) {
                            $('#dguser').datagrid('reload');
                            msg('Success !', 'Berhasil Di Hapus');
                        } else {
                            msg('Error', result.errorMsg);
                        }
                    }, 'json');
                }
            });
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function save() {
        ($('#nama').val() == '') ? [msg('Error', 'NAMA harus di isi'), $('#nama').focus(), exit] : '';
        ($('#jabatan').val() == '') ? [msg('Error', 'jabatan harus di isi'), $('#jabatan').focus(), exit] : '';
        $('#fm').form('submit', {
            url: '<?= XROOT ?>admin_web/save_team',
            ajax: 'true',
            iframe: 'false',
            onSubmit: function() {
                return $(this).form('validate');
            },
            success: function(result) {
                var result = eval('(' + result + ')');
                if (result.success) {
                    ($('#id').val() == 'insert') ? spring(): '';
                    msg('Success !', 'Berhasil di Save');
                } else {
                    msg('Error', result.errorMsg);
                }
            }
        });
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function spring() {
        if (document.getElementById('type2').checked) {
            window.location.reload();
        } else {
            hid();
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    $(function() {
        $('#dguser').datagrid({
            singleSelect: true,
            onRowContextMenu: function(e, index, row) {
                document.getElementById('id').value = row.id;
                if (row.type == 'USERS') {
                    $("#lbtumb").hide();
                } else {
                    $("#lbtumb").show();
                }
                if (row.status == 'true') {
                    document.getElementById("btn-status").innerHTML = '<i class="fa fa-globe text-danger mr-2"></i>Hide in Web';
                } else {
                    document.getElementById("btn-status").innerHTML = '<i class="fa fa-globe text-success mr-2"></i>Show in Web';
                }
                $(this).datagrid('selectRow', index);
                e.preventDefault();
                $('#mm').menu('show', {
                    left: e.pageX,
                    top: e.pageY
                });
            },
            onDblClickRow: function() {
                edit();
            }
        })

    })
    //-----------------------------------------end
    //===========================================
    function thumbnail() {
        $("#head2").html('<small class="float-left"><i class="fa fa-image mr-2"></i>Halaman Crop Foto</small>');
        $('#fo1').hide();
        $('#fo2').hide();
        $('#fo3').show();
        var property = document.getElementById('thumbnail').files[0];
        var name = property.name;
        var extension = name.split('.').pop().toLowerCase();
        var e = extension;
        if (e !== 'png' && e !== 'jpg' && e !== 'jpeg' && e !== 'gif' && e !== 'webp' && e !== 'svg') {
            $('#temp_foto').croppie('destroy');
            msg('Error !', 'Extensi Gambar Harus [ png,jpg,jpeg,gif,webp,svg ].');
            exit;
        }
        $image_crop = $('#temp_foto').croppie({
            enableExif: true,
            viewport: {
                width: 300,
                height: 400,
                type: 'square'
            }, //circle 
            boundary: {
                width: 300,
                height: 400
            }
        });
        var reader = new FileReader();
        reader.onload = function(event) {
            $image_crop.croppie('bind', {
                url: event.target.result
            }).then(function() {
                console.log('jQuery bind complete');
            });
        }
        reader.readAsDataURL(property);
        // $('#foto').modal('show');
    }
    //===========================================
    //==========================================================
    function crop() {
        var id = document.getElementById('id').value;
        $image_crop.croppie('result', {
            type: 'canvas',
            size: 'viewport'
        }).then(function(response) {
            $.ajax({
                url: "<?= XROOT ?>admin_web/upload_team",
                type: "POST",
                data: {
                    "image": response,
                    "id": id
                },
                success: function(data) {
                    hid();
                    msg('Success !', 'Foto Berhasil Di Ganti.')
                }
            });
        });
    }
    //==========================================================
</script>