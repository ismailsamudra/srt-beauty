<!-- TOP NAVIGASI START -->
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <small>
            <?php btback() ?>
            <a href="javascript:void(0);" onclick="add()" class="btn-sm bt-1 float-left" title="ADD"><i class="fa fa-plus"></i></a>
            <a href="" style="color: <?= color('primary-b') ?>;">
                <strong>
                    <i class="fa fa-globe mr-2"></i> <?= strtoupper(str_replace('/', ' ', XURI)) ?>
                </strong>
            </a>
            <a href="javascript:void(0);" onclick="$('#dguser').datagrid('reload');" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
        </small>
    </center>
</div>
<!-- TOP NAVIGASI END -->
<!-- BODY START -->
<input type="hidden" id="idx">
<div class="row m-2">
    <div class="col-md-9 mb-2 mt-2 table-responsive">
        <div class="row">

            <div class="col-12" id="fo1">
                <center>
                    <table id="dguser" toolbar="" class="easyui-datagrid" singleSelect="true" style="width: 100%;" fitColumns="true" rowNumbers="true" pagination="false" url="<?= XROOT ?>admin_web/get_visi_misi" pageSize="10" pageList="[10,25,50,75,100,125,150,200]">
                        <thead>
                            <tr>
                                <th field="pur_res" width="100%" formatter="show_res"></th>
                            </tr>
                        </thead>
                    </table>
                </center>
            </div>

        </div>

    </div>
    <div class="col-md-3 mb-2 mt-2 table-responsive">
        <div class="container">
            <div class="">
                <strong>
                    M-BOOK :
                </strong>
                <hr>
                Doubel Klick pada baris data Untuk Edit
                <hr>
                Untuk Menu Lain Klick Kanan jika desktop dan sentuh tahan jika HP.
                <hr>
            </div>
            <br>
        </div>
        <center>
            <i class="fa fa-globe fa-5x"></i><br>
            <strong>
                <?= strtoupper(str_replace('/', ' ', XURI)) ?>
            </strong><br>
        </center>
    </div>
</div>
<!-- BODY END -->
<!-- KLICK KANAN START -->
<div id="mm" class="easyui-menu">
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="edit();"><i class="far fa-edit mr-2"></i> Edit</a>
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="change_status();"><span id="btn-status"></span></a>
    <a href="javascript:void(0)" class="btn-sm form-control" plain="true" onClick="destroyuser();"><i class="fa fa-trash mr-2 text-danger"></i> Hapus</a>
</div>
<!-- KLICK KANAN END -->
<!-- Start Modal 1 -->
<div class="modal fade" id="edit" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div id="head"></div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <form id="fm" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="id" id="id">
                    <div class="card col">
                        <div class="row">
                            <div class="col-md-3">
                                <strong><small>ROLE :</small></strong>
                            </div>
                            <div class="col-md-3">
                                <input type="radio" name="role" id="role1" value="visi" class="mr-2">VISI
                            </div>
                            <div class="col-md-3">
                                <input type="radio" name="role" id="role2" value="misi" class="mr-2">MISI
                            </div>
                            <div class="col-md-3">
                                <input type="radio" name="role" id="role3" value="tujuan" class="mr-2">TUJUAN
                            </div>
                        </div>
                    </div>
                    <small>TEXT</small>
                    <textarea name="text" id="text" cols="30" rows="4" class="form-control"></textarea>
                </form>

            </div>
            <div class="modal-footer">
                <a href="javascript:void(0);" onclick="save();" class="btn btn-outline-dark btn-sm"><i class="fa fa-save mr-2"></i>Save</a>
            </div>

        </div>
    </div>
</div>
<!-- End Modal 1-->
<script type="text/javascript">
    //-----------------------------------------start
    function show_res(val, row) {
        for (var name in row) {
            status = (row.status == 'true') ? 'YA' : 'TIDAK';
            var t = `
            <div class="card col table-responsive my-1">
                <div class="row mt-1">
                <div class="col-md-2">
                    <small>Tampikan Di Web</small>
                </div>
                <div class="col-md-10">
                <strong> ` + status + `</strong>  
                </div>
                    <div class="col-md-1">
                        <strong>ROLE</strong>
                    </div>
                    <div class="col-md-11">
                    <strong>: ` + row.role + `</strong>  
                    </div>
                </div>
                <div class="row my-1">
                    <div class="col-md-1">
                        <strong>TEXT</strong>
                    </div>
                    <div class="col-md-11">
                    <textarea cols="30" rows="2" class="form-control" readonly>` + row.text + `</textarea>
                    </div>
                </div>
            </div>
            `;
            if (row["pur_res"] == "Received") {} else {
                return t;
            }
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function add() {
        $('#fm').form('clear');
        document.getElementById("head").innerHTML = '<h5 class="modal-title"><i class="fa fa-plus mr-2"></i>Tambah Data</h5>';
        document.getElementById("id").value = 'insert';
        document.getElementById("role1").checked = true;
        $('#edit').modal('show');

    }
    //-----------------------------------------end
    //-----------------------------------------start
    function edit() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $('#fm').form('load', row);
            document.getElementById("head").innerHTML = '<h5 class="modal-title"><i class="fa fa-edit mr-2"></i>Edit Data</h5>';
            $('#edit').modal('show');
        } else {
            msg('Error', 'Klick Sekali Lagi');
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function change_status() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $.messager.confirm('Attention!', '<strong class="text-danger">Hati-hati Melakukan aksi ini,</strong><br> Apakah Anda Yakin Ingin Merubah Status data ini ?<br>ROLE : ' + row.role, function(r) {
                if (r) {
                    $.post("<?= XROOT ?>admin_web/status_visi_misi", {
                        id: row.id
                    }, function(result) {
                        if (result.success) {
                            $('#dguser').datagrid('reload');
                            msg('Success !', 'Status Berhasil Di Ubah');
                        } else {
                            msg('Error', result.errorMsg);
                        }
                    }, 'json');
                }
            });
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function destroyuser() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $.messager.confirm('Attention!', '<strong class="text-danger">Hati-hati Melakukan aksi ini,</strong><br> Apakah Anda Yakin Ingin Menghapus data ini ?<br>ROLE : ' + row.role, function(r) {
                if (r) {
                    $.post("<?= XROOT ?>admin_web/del_visi_misi", {
                        id: row.id
                    }, function(result) {
                        if (result.success) {
                            $('#dguser').datagrid('reload');
                            msg('Success !', 'Berhasil Di Hapus');
                        } else {
                            msg('Error', result.errorMsg);
                        }
                    }, 'json');
                }
            });
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function save() {
        ($('#text').val() == '') ? [msg('Error !', 'Text Harus Di isi'), $('#text').focus(), exit] : '';
        $('#fm').form('submit', {
            url: '<?= XROOT ?>admin_web/save_visi_misi',
            onSubmit: function() {
                return $(this).form('validate');
            },
            success: function(result) {
                var result = eval('(' + result + ')');
                if (result.success) {
                    $('#edit').modal('hide');
                    $('#dguser').datagrid('reload');
                    msg('Success !', 'Berhasil di Save');
                } else {
                    msg('Error', result.errorMsg);
                }
            }
        });
    }
    //-----------------------------------------end
    //-----------------------------------------start
    $(function() {
        $('#dguser').datagrid({
            singleSelect: true,
            onRowContextMenu: function(e, index, row) {
                if (row.status == 'true') {
                    document.getElementById("btn-status").innerHTML = '<i class="fa fa-globe text-danger mr-2"></i>Hide in Web';
                } else {
                    document.getElementById("btn-status").innerHTML = '<i class="fa fa-globe text-success mr-2"></i>Show in Web';
                }
                $(this).datagrid('selectRow', index);
                e.preventDefault();
                $('#mm').menu('show', {
                    left: e.pageX,
                    top: e.pageY
                });
            },
            onDblClickRow: function() {
                edit();
            }
        })

    })
    //-----------------------------------------end
</script>