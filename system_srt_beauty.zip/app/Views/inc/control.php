<!-- TOP NAVIGASI START -->
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <small>
            <?php btback() ?>
            <h5><small><i class="fab fa-whmcs mr-2"></i> <?= strtoupper(str_replace('/', ' ', XURI)) ?></small>
                <a href="" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
            </h5>
        </small>
    </center>
</div>
<!-- TOP NAVIGASI END -->
<!-- BODY START -->
<div class="container mt-2">

    <div class="col-12">
        <div class="row">
            <div class="col-md-12 mb-2">
                <div class="card bg-1">
                    <div class="col">
                        <small>
                            <strong>
                                CONTROL SETTING
                            </strong>
                        </small>
                    </div>
                </div>
            </div>
            <div class="col-md-12">

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <small><strong>PASSWORD DEFAULT</strong></small>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <div class="row">
                                <div class="col-md-10">
                                    <div id="pass_default_lb"><strong><?= inc('pass_default'); ?></strong></div>
                                    <input type="text" id="pass_default" style="height: 23px;" value="<?= inc('pass_default') ?>" class="form-control">
                                </div>
                                <div class="col-md-2">
                                    <x>
                                        <a href="javascript:void(0);" id="bt_e_pass_default" class="float-right" onclick="pass_e('pass_default')"><i class="fa fa-edit" title="Edit"></i></a>
                                        <a href="javascript:void(0);" id="bt_s_pass_default" class="float-right" onclick="save('pass_default')"><i class="fa fa-save" title="Save"></i></a>
                                    </x>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <small><strong>MAINTENANCE</strong></small>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <div class="row col">
                                <div class="col-md-6">
                                    <input type="radio" name="maint" id="maint1" onclick="status('maintenance','')" class="mr-2" value="true">ENABLE
                                </div>
                                <div class="col-md-6">
                                    <input type="radio" name="maint" id="maint2" onclick="status('maintenance','')" class="mr-2" value="false">DISABLE
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <small><strong>WEBSITE</strong></small>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <div class="row col">
                                <div class="col-md-6">
                                    <input type="radio" name="status" id="status1" onclick="status('web_status','')" class="mr-2" value="true">ENABLE
                                </div>
                                <div class="col-md-6">
                                    <input type="radio" name="status" id="status2" onclick="status('web_status','')" class="mr-2" value="false">DISABLE
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <small><strong>REGISTER</strong></small>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <div class="row col">
                                <div class="col-md-6">
                                    <input type="radio" name="reg" id="reg1" onclick="status('register','')" class="mr-2" value="true">ENABLE
                                </div>
                                <div class="col-md-6">
                                    <input type="radio" name="reg" id="reg2" onclick="status('register','')" class="mr-2" value="false">DISABLE
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <small><strong>REGISTER LEVEL</strong></small>
                        </div>
                    </div>
                    <?php
                    $no = 1;
                    $lvl = db('engine')->getWhere(['sync' => '0', 'role' => 'DEFAULT_AKSES'])->getResult();
                    ?>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <div class="row col">
                                <div class="col-md-12">
                                    <input type="radio" name="level" id="null" onclick="status('null','level')" class="mr-2" value="true">DISABLE
                                </div>
                                <?php foreach ($lvl as $o) : ?>
                                    <div class="col-md-12">
                                        <input type="radio" name="level" id="<?= $o->level ?>" onclick="status('<?= $o->level ?>','level')" class="mr-2" value="true"><?= $o->level_name ?>
                                    </div>
                                <?php endforeach ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <small><strong>LUPA PASSWORD</strong></small>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <div class="row col">
                                <div class="col-md-6">
                                    <input type="radio" name="forgot" id="forgot1" onclick="status('forgot','')" class="mr-2" value="true">ENABLE
                                </div>
                                <div class="col-md-6">
                                    <input type="radio" name="forgot" id="forgot2" onclick="status('forgot','')" class="mr-2" value="false">DISABLE
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <div class="col-md-12 mb-2">
                <div class="card bg-1">
                    <div class="col">
                    </div>
                </div>
            </div>

        </div>
    </div>

</div>
<!-- BODY END -->
<script type="text/javascript">
    var maint = "<?= inc('maintenance') ?>";
    if (maint == 'true') {
        document.getElementById('maint2').checked = false;
        document.getElementById('maint1').checked = true;
    } else {
        document.getElementById('maint1').checked = false;
        document.getElementById('maint2').checked = true;
    }
    var sts = "<?= inc('web_status') ?>";
    if (sts == 'true') {
        document.getElementById('status2').checked = false;
        document.getElementById('status1').checked = true;
    } else {
        document.getElementById('status1').checked = false;
        document.getElementById('status2').checked = true;
    }
    var reg = "<?= inc('register') ?>";
    if (reg == 'true') {
        document.getElementById('reg2').checked = false;
        document.getElementById('reg1').checked = true;
    } else {
        document.getElementById('reg1').checked = false;
        document.getElementById('reg2').checked = true;
    }
    var forgot = "<?= inc('forgot') ?>";
    if (forgot == 'true') {
        document.getElementById('forgot2').checked = false;
        document.getElementById('forgot1').checked = true;
    } else {
        document.getElementById('forgot1').checked = false;
        document.getElementById('forgot2').checked = true;
    }

    var level = "<?= inc('level_regist') ?>";
    document.getElementById(level).checked = true;
    $('#pass_default_lb').show();
    $('#pass_default').hide();
    $('#bt_s_pass_default').hide();
    $('#bt_e_pass_default').show();
    $('#rm_a_lb').show();
    $('#rm_a').hide();
    $('#bt_s_rm_a').hide();
    $('#bt_e_rm_a').show();
    //===========================================
    function pass_e(id) {
        $('#bt_e_' + id).hide();
        $('#bt_s_' + id).show();
        $('#' + id + '_lb').hide();
        $('#' + id).show();
        $('#' + id).focus();
    }
    //===========================================
    //===========================================
    function save(id) {
        var val = document.getElementById(id).value;
        var url = '<?= XROOT ?>inc/save_text2';
        $.post(url, {
            id,
            val
        }, function(result) {
            if (result.success) {
                document.getElementById(id + '_lb').innerHTML = '<strong>' + val + '</strong>';
                $('#' + id).hide();
                $('#' + id + '_lb').show();
                $('#bt_s_' + id).hide();
                $('#bt_e_' + id).show();
                $.messager.show({ // show error message
                    title: 'Success !',
                    msg: 'Berhasil di Update.'
                });
            } else {
                $.messager.show({ // show error message
                    title: 'Error !',
                    msg: result.errorMsg
                });
            }
        }, 'json');
    }
    //===========================================
    //===========================================
    function status(id, act) {
        var url = '<?= XROOT ?>inc/status2';
        $.post(url, {
            id,
            act
        }, function(result) {
            if (result.success) {
                $.messager.show({ // show error message
                    title: 'Success !',
                    msg: 'Status berhasil di Update.'
                });
            } else {
                $.messager.show({ // show error message
                    title: 'Error !',
                    msg: result.errorMsg
                });
            }
        }, 'json');
    }
    //===========================================
</script>