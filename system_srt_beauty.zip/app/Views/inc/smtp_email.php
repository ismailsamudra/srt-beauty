<link rel="stylesheet" href="<?= XROOT ?>script/summernote/summernote-bs4.min.css">
<script src="<?= XROOT ?>script/summernote/summernote-bs4.min.js"></script>
<!-- TOP NAVIGASI START -->
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <small>
            <?php btback() ?>
            <h5><small><i class="far fa-envelope mr-2"></i> <?= strtoupper(str_replace('/', ' ', XURI)) ?></small>
                <a href="" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
            </h5>
        </small>
    </center>
</div>
<!-- TOP NAVIGASI END -->
<!-- BODY START -->
<div class="container mt-2">

    <div class="col-12">
        <div class="row">
            <div class="col-md-12 mb-2">
                <div class="card bg-1">
                    <div class="col">
                        <small>
                            <strong>
                                <x>
                                    HARAP RAHASIAKAN HALAMAN INI
                                    <a href="javascript:void(0);" onclick="test();" class="float-right pri-b">TEST KIRIM</a>
                                </x>
                            </strong>
                        </small>
                    </div>
                </div>
            </div>
            <div class="col-md-12">

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <small><strong>STATUS</strong></small>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <div class="row col">
                                <div class="col-md-6">
                                    <input type="radio" name="email_status" id="email_status1" onclick="status('email_status','')" class="mr-2" value="true">ENABLE
                                </div>
                                <div class="col-md-6">
                                    <input type="radio" name="email_status" id="email_status2" onclick="status('email_status','')" class="mr-2" value="false">DISABLE
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <small><strong>SMTP HOST</strong></small>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <div class="row">
                                <div class="col-md-10">
                                    <div id="email_host_lb"><strong><?= inc('email_host'); ?></strong></div>
                                    <input type="text" id="email_host" style="height: 23px;" value="<?= inc('email_host') ?>" class="form-control">
                                </div>
                                <div class="col-md-2">
                                    <x>
                                        <a href="javascript:void(0);" id="bt_e_email_host" class="float-right" onclick="pass_e('email_host')"><i class="fa fa-edit" title="Edit"></i></a>
                                        <a href="javascript:void(0);" id="bt_s_email_host" class="float-right" onclick="save('email_host')"><i class="fa fa-save" title="Save"></i></a>
                                    </x>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <small><strong>USER</strong></small>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <div class="row">
                                <div class="col-md-10">
                                    <div id="email_user_lb"><strong><?= inc('email_user'); ?></strong></div>
                                    <input type="text" id="email_user" style="height: 23px;" value="<?= inc('email_user') ?>" class="form-control">
                                </div>
                                <div class="col-md-2">
                                    <x>
                                        <a href="javascript:void(0);" id="bt_e_email_user" class="float-right" onclick="pass_e('email_user')"><i class="fa fa-edit" title="Edit"></i></a>
                                        <a href="javascript:void(0);" id="bt_s_email_user" class="float-right" onclick="save('email_user')"><i class="fa fa-save" title="Save"></i></a>
                                    </x>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <small><strong>PASSWORD</strong> (Dilindungi enscripsi)</small>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <div class="row">
                                <div class="col-md-10">
                                    <div id="email_pass_lb"><strong>********</strong></div>
                                    <input type="password" id="email_pass" style="height: 23px;" value="<?= dekey(inc('email_pass')) ?>" class="form-control">
                                </div>
                                <div class="col-md-2">
                                    <x>
                                        <a href="javascript:void(0);" id="bt_e_email_pass" class="float-right" onclick="pass_e('email_pass')"><i class="fa fa-edit" title="Edit"></i></a>
                                        <a href="javascript:void(0);" id="bt_s_email_pass" class="float-right" onclick="save('email_pass')"><i class="fa fa-save" title="Save"></i></a>
                                    </x>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <small><strong>PORT</strong></small>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <div class="row">
                                <div class="col-md-10">
                                    <div id="email_port_lb"><strong><?= inc('email_port'); ?></strong></div>
                                    <input type="text" id="email_port" style="height: 23px;" value="<?= inc('email_port') ?>" class="form-control">
                                </div>
                                <div class="col-md-2">
                                    <x>
                                        <a href="javascript:void(0);" id="bt_e_email_port" class="float-right" onclick="pass_e('email_port')"><i class="fa fa-edit" title="Edit"></i></a>
                                        <a href="javascript:void(0);" id="bt_s_email_port" class="float-right" onclick="save('email_port')"><i class="fa fa-save" title="Save"></i></a>
                                    </x>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <small><strong>SMTP CRIPTO</strong></small>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <div class="row col">
                                <div class="col-md-6">
                                    <input type="radio" name="email_cripto" id="ssl" onclick="status('email_cripto',this.value)" class="mr-2" value="ssl">SSL
                                </div>
                                <div class="col-md-6">
                                    <input type="radio" name="email_cripto" id="tsl" onclick="status('email_cripto',this.value)" class="mr-2" value="tsl">TSL
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <small><strong>MAIL TYPE</strong></small>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <div class="row col">
                                <div class="col-md-6">
                                    <input type="radio" name="email_type" id="html" onclick="status('email_type',this.value)" class="mr-2" value="html">HTML
                                </div>
                                <div class="col-md-6">
                                    <input type="radio" name="email_type" id="text" onclick="status('email_type',this.value)" class="mr-2" value="text">TEXT
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-md-4">
                        <div class="card col table-responsive">
                            <small><strong>PROTOCOL</strong></small>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card col table-responsive">
                            <div class="row col">
                                <div class="col-md-12">
                                    <input type="radio" name="email_protocol" id="smtp" onclick="status('email_protocol',this.value)" class="mr-2" value="smtp">SMTP
                                </div>
                                <div class="col-md-12">
                                    <input type="radio" name="email_protocol" id="mail" onclick="status('email_protocol',this.value)" class="mr-2" value="mail">MAIL
                                </div>
                                <div class="col-md-12">
                                    <input type="radio" name="email_protocol" id="sendmail" onclick="status('email_protocol',this.value)" class="mr-2" value="sendmail">SENDMAIL
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <div class="col-md-12 mb-2">
                <div class="card bg-1">
                    <div class="col">
                    </div>
                </div>
            </div>

        </div>
    </div>

</div>
<!-- BODY END -->
<!-- Start Modal 1 -->
<div class="modal fade" id="test" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="far fa-envelope mr-2"></i>KIRIM EMAIL</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body rol-300">
                <small>KEPADA</small>
                <input type="email" class="form-control" placeholder="Email Penerima" id="to">
                <small>JUDUL</small>
                <input type="email" class="form-control" placeholder="Judul Pesan" id="judul">
                <small>PESAN</small>
                <textarea name="msg" id="msg" class="form-control" rows="4"></textarea>
            </div>
            <div class="modal-footer">
                <a href="javascript:void(0);" onclick="send()" class="btn btn-outline-dark btn-sm"><i class="far fa-paper-plane mr-2"></i>Kirim</a>
            </div>
        </div>

    </div>
</div>
</div>
<!-- End Modal 1-->
<!-- Start Modal 1 -->
<div class="modal fade" id="temp_m" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fa fa-edit mr-2"></i>EDIT TEMPLATE</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body rol-300">
                <small><strong>NB : Insert Image hanya terbaca dalam email jika type URL</strong></small>
                <textarea name="temp" id="temp" class="form-control" rows="4"></textarea>
            </div>
            <div class="modal-footer">
                <a href="javascript:void(0);" onclick="save_t()" class="btn btn-outline-dark btn-sm"><i class="far fa-paper-plane mr-2"></i>Kirim</a>
            </div>
        </div>

    </div>
</div>
</div>
<!-- End Modal 1-->
<input type="hidden" id="class_id">
<script type="text/javascript">
    $('#temp').summernote({
        height: 180,
        // themes:paper,
        airMode: false
    })
    $('#msg').summernote({
        height: 240,
        // themes:paper,
        airMode: false
    })
    var email_type = "<?= inc('email_type') ?>";
    document.getElementById(email_type).checked = true;
    var email_cripto = "<?= inc('email_cripto') ?>";
    document.getElementById(email_cripto).checked = true;
    var email_protocol = "<?= inc('email_protocol') ?>";
    document.getElementById(email_protocol).checked = true;
    var email_status = "<?= inc('email_status') ?>";
    if (email_status == 'true') {
        document.getElementById('email_status2').checked = false;
        document.getElementById('email_status1').checked = true;
    } else {
        document.getElementById('email_status1').checked = false;
        document.getElementById('email_status2').checked = true;
    }
    //---------------------------
    $('#email_host_lb').show();
    $('#email_host').hide();
    $('#bt_s_email_host').hide();
    $('#bt_e_email_host').show();
    //---------------------------
    //---------------------------
    $('#email_user_lb').show();
    $('#email_user').hide();
    $('#bt_s_email_user').hide();
    $('#bt_e_email_user').show();
    //---------------------------
    //---------------------------
    $('#email_pass_lb').show();
    $('#email_pass').hide();
    $('#bt_s_email_pass').hide();
    $('#bt_e_email_pass').show();
    //---------------------------
    //---------------------------
    $('#email_port_lb').show();
    $('#email_port').hide();
    $('#bt_s_email_port').hide();
    $('#bt_e_email_port').show();
    //---------------------------
    //===========================================
    function temp(id) {
        document.getElementById('class_id').value = id;
        var val = document.getElementById(id).value;
        $('#temp').summernote('code', atob(val));
        $('#temp_m').modal('show');
    }

    function test() {
        document.getElementById('to').value = '';
        document.getElementById('judul').value = '';
        $('#msg').summernote('code', '');
        $('#test').modal('show');
    }

    function send() {
        $("#load").modal({
            backdrop: "static"
        });
        var file = '';
        var to = document.getElementById('to').value;
        var judul = document.getElementById('judul').value;
        var msg = document.getElementById('msg').value;
        var url = '<?= XROOT ?>apps/send_email/json';
        $.post(url, {
            to,
            judul,
            msg,
            file
        }, function(result) {
            if (result.success) {
                $('#test').modal('hide');
                $.messager.show({ // show error message
                    title: 'Success !',
                    msg: 'Berhasil di Kirim.'
                });
            } else {
                $.messager.show({ // show error message
                    title: 'Error !',
                    msg: result.errorMsg
                });
            }
            $("#load").modal('hide');
        }, 'json');
    }
    //===========================================
    //===========================================
    function pass_e(id) {
        $('#bt_e_' + id).hide();
        $('#bt_s_' + id).show();
        $('#' + id + '_lb').hide();
        $('#' + id).show();
        $('#' + id).focus();
    }
    //===========================================
    //===========================================
    function save_t() {
        var id = document.getElementById('class_id').value;
        var val = document.getElementById('temp').value;
        var url = '<?= XROOT ?>inc/save_text';
        $.post(url, {
            id,
            val
        }, function(result) {
            if (result.success) {
                $('#temp_m').modal('hide');
                document.getElementById(id).value = val;
                $.messager.show({ // show error message
                    title: 'Success !',
                    msg: 'Berhasil di Update.'
                });
                window.location.reload();
            } else {
                $.messager.show({ // show error message
                    title: 'Error !',
                    msg: result.errorMsg
                });
            }
        }, 'json');
    }
    //===========================================
    //===========================================
    function save(id) {
        var val = document.getElementById(id).value;
        var url = '<?= XROOT ?>inc/save_text';
        $.post(url, {
            id,
            val
        }, function(result) {
            if (result.success) {
                if (id == 'email_pass') {
                    document.getElementById(id + '_lb').innerHTML = '<strong>********</strong>';
                } else {
                    document.getElementById(id + '_lb').innerHTML = '<strong>' + val + '</strong>';
                }
                $('#' + id).hide();
                $('#' + id + '_lb').show();
                $('#bt_s_' + id).hide();
                $('#bt_e_' + id).show();
                $.messager.show({ // show error message
                    title: 'Success !',
                    msg: 'Berhasil di Update.'
                });
            } else {
                $.messager.show({ // show error message
                    title: 'Error !',
                    msg: result.errorMsg
                });
            }
        }, 'json');
    }
    //===========================================
    //===========================================
    function status(id, act) {
        var url = '<?= XROOT ?>inc/status';
        $.post(url, {
            id,
            act
        }, function(result) {
            if (result.success) {
                $.messager.show({ // show error message
                    title: 'Success !',
                    msg: 'Status berhasil di Update.'
                });
            } else {
                $.messager.show({ // show error message
                    title: 'Error !',
                    msg: result.errorMsg
                });
            }
        }, 'json');
    }
    //===========================================
</script>