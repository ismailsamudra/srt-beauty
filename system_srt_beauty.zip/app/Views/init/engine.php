<!-- TOP NAVIGASI START -->
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <small>
            <?php btback() ?>
            <h5>
                <a href="" style="color: <?= color('primary-b') ?>;">
                    <small>
                        <strong>
                            <i class="fab fa-react mr-2"></i> <?= strtoupper(str_replace('/', ' ', XURI)) ?>
                        </strong>
                    </small>
                </a>
            </h5>
        </small>
    </center>
</div>
<!-- TOP NAVIGASI END -->
<input type="hidden" id="aks">
<input type="hidden" id="lvl">
<!-- BODY START -->
<div class="row m-2">
    <div class="col-md-9 mb-2 mt-2 table-responsive">
        <div id="a3">
            <div class="card mb-2 bg-1">
                <div class="col">
                    <div class="row">
                        <div class="col-md-4">
                            <label id="lb3"></label>
                        </div>
                        <div class="col-md-4">
                            <label id="lb4"></label>
                        </div>
                        <div class="col-md-4">
                            <a href="javascript:void(0);" onclick="$('#dguser3').datagrid('reload');$('#dguser4').datagrid('reload');" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
                            <a href="javacript:void(0);" class="btn-sm float-right bt-1 mr-2" onclick="hide2()"><i class="fa fa-times text-danger"></i></a>
                            <a href="javacript:void(0);" class="btn-sm float-right bt-1 mr-2" onclick="add2()"><i class="fa fa-plus"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <center>
                        <table id="dguser3" class="easyui-datagrid" singleSelect="true" style="width: 100%;" fitColumns="true" rowNumbers="false" pagination="false" url="">
                            <thead>
                                <tr>
                                    <th field="pur_sc" formatter="show_sc" width="100%" align="left">GROUP-1</th>
                                </tr>
                            </thead>
                        </table>
                    </center>
                </div>
                <div class="col-md-6">
                    <center>
                        <table id="dguser4" class="easyui-datagrid" singleSelect="true" style="width: 100%;" fitColumns="true" rowNumbers="false" pagination="false" url="">
                            <thead>
                                <tr>
                                    <th field="pur_sc" formatter="show_sc" width="100%" align="left">GROUP-2</th>
                                </tr>
                            </thead>
                        </table>
                    </center>
                </div>
            </div>
        </div>
        <div id="a2">
            <div class="card mb-2 bg-1">
                <div class="col">
                    <div class="row">
                        <div class="col-md-6">
                            <label id="lb1"></label>
                        </div>
                        <div class="col-md-4">
                            <label id="lb2"></label>
                        </div>
                        <div class="col-md-2">
                            <a href="javascript:void(0);" onclick="$('#dguser2').datagrid('reload');" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
                            <a href="javacript:void(0);" class="btn-sm float-right bt-1 mr-2" onclick="hide1()"><i class="fa fa-times text-danger"></i></a>
                        </div>
                    </div>
                </div>
            </div>

            <center>
                <table id="dguser2" class="easyui-datagrid" singleSelect="true" style="width: 100%;" fitColumns="true" rowNumbers="false" pagination="true" url="<?= XROOT ?>init/get_sidebar" pageSize="1000" pageList="[10,25,50,100,200,500,1000,2000,5000]">
                    <thead>
                        <tr>
                            <th field="pur_col1" width="300px" formatter="show_col1" align="left">SIDEBAR-1</th>
                            <th field="pur_col2" width="300px" formatter="show_col2" align="left">SIDEBAR-2</th>
                            <th field="pur_col3" width="300px" formatter="show_col3" align="left">SIDEBAR-3</th>

                        </tr>
                    </thead>
                </table>
            </center>
        </div>
        <div id="a1">
            <div class="card mb-2 bg-1">
                <div class="col">
                    <div class="row">
                        <div class="col-md-6">
                            <label>USER ENGINE</label>
                        </div>
                        <div class="col-md-4">

                        </div>
                        <div class="col-md-2">
                            <a href="javascript:void(0);" onclick="$('#dguser').datagrid('reload');" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
                            <a href="javacript:void(0);" class="btn-sm float-right bt-1 mr-2" onclick="add()"><i class="fa fa-plus"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <center>
                <table id="dguser" toolbar="#toolbarCustomer" class="easyui-datagrid" singleSelect="true" style="width: 100%;height:1000px;" fitColumns="true" rowNumbers="false" pagination="false" url="<?= XROOT ?>init/get_engine" pageSize="10" pageList="[10,25,50,75,100,125,150,200]">
                    <thead>
                        <tr>
                            <th field="pur_grup" formatter="show_grup" sortable="true" align="center">Group</th>
                            <th field="pur_lvln" formatter="show_lvln" sortable="true">LEVEL NAME</th>
                            <th field="pur_lvl" formatter="show_lvl" sortable="true" align="left">LEVEL ID</th>
                            <th field="pur_akses" formatter="show_akses" width="100" sortable="true">AKSES NAME</th>
                            <th field="akses" sortable="true">AKSES ID</th>
                            <th field="role" sortable="true">ROLE</th>
                        </tr>
                    </thead>
                </table>
            </center>
        </div>
    </div>
    <div class="col-md-3 mb-2 mt-2 table-responsive">
        <div class="container">
            <div class="text-danger">
                <strong>
                    Attention!
                </strong><br>
                Hati-hati dalam menggunakan aksi hapus
                di karenakan ada beberapa data lain yg terkait dengan data ini
                akan ikut terhapus atau tidak terdeteksi.
                Harap mempelajari terlebih dahulu arah datanya.
            </div>
            <br>
            <br>
            <br>
        </div>
        <center>
            <i class="fab fa-react fa-5x"></i><br>
            <strong>
                <?= strtoupper(str_replace('/', ' ', XURI)) ?>
            </strong><br>
        </center>
    </div>
</div>
<!-- BODY END -->
<!-- TOOLBAR START -->
<div id="toolbarCustomer">
    <div class="row">
        <div class="col-md-6">
            <!---------SEARCH BOX START--------->
            <input id="searchCustomer" class="easyui-searchbox" data-options="prompt:'Cari..',searcher:doSearchCustomer,
            inputEvents: $.extend({}, $.fn.searchbox.defaults.inputEvents, {
                keyup: function(e){
                    var t = $(e.data.target);
                    var opts = t.searchbox('options');
                    t.searchbox('setValue', $(this).val());
                    opts.searcher.call(t[0],t.searchbox('getValue'),t.searchbox('getName'));
                }
            })
        " style="width:100%;"></input>
            <script>
                function doSearchCustomer() {
                    $('#dguser').datagrid('load', {
                        search_customer: $('#searchCustomer').val()
                    });
                }
            </script>
            <!---------SEARCH BOX END----------->
        </div>

    </div>
</div>
<!-- TOOLBAR END -->
<!-- RIGHT BUTTON START -->
<div id="mm" class="easyui-menu" style="border: 0px;">
    <a id="subakses"></a>
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="update();"><i class="far fa-edit mr-2"></i> Edit</a>
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="barschema();"><i class="fa fa-align-left mr-2"></i> Bar Schema</a>
    <a id="btschema"></a>
    <a id="btdel"></a>
</div>
<div id="mm3" class="easyui-menu" style="border: 0px;">
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="upschema('3');"><i class="far fa-edit mr-2"></i> Edit</a>
    <a id="bth3"></a>
</div>
<div id="mm4" class="easyui-menu" style="border: 0px;">
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="upschema('4');"><i class="far fa-edit mr-2"></i> Edit</a>
    <a id="bth4"></a>
</div>
<!-- RIGHT BUTTON END -->
<!-- Start Modal 1 -->
<div class="modal fade" id="modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div id="head"></div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="fm" method="post">
                    <input type="hidden" id="id" name="id">
                    <input type="hidden" id="level" name="level">
                    <div class="row">
                        <div class="col-md-3">
                            Group
                            <input type="number" name="grup" id="grup" class="form-control" required>
                        </div>
                        <div class="col-md-9">
                            Level Name
                            <input type="text" name="level_name" id="level_name" class="form-control" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3">
                            No.
                            <input type="number" name="no" id="no" class="form-control" required>
                        </div>
                        <div class="col-md-9">
                            Akses Name
                            <input type="text" name="akses_name" id="akses_name" class="form-control" required>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <a href="javascript:void(0)" onclick="save();" class="btn btn-outline-dark btn-sm"><i class="fa fa-save mr-2"></i>Save</a>
            </div>
        </div>
    </div>
</div>
<!-- End Modal 1-->
<!-- Start Modal 2 -->
<div class="modal fade" id="modal2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <div id="head2"></div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="fm2" method="post">
                    <input type="hidden" name="id" id="id2">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="col-12">
                                <small>Group</small>
                                <div class="row col">
                                    <div class="col-6">
                                        <input type="radio" name="group" id="group1" class="mr-2" value="1">1
                                    </div>
                                    <div class="col-6">
                                        <input type="radio" name="group" id="group2" class="mr-2" value="2">2
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <small>Label</small>
                                <input type="text" class="form-control" id="label" name="label" required>
                            </div>
                            <div class="row">
                                <div class="col-7">
                                    <small>Type</small>
                                    <select name="type" id="type" class="form-control" required>
                                        <option value="text">text</option>
                                        <option value="select">select</option>
                                        <option value="email">email</option>
                                        <option value="number">number</option>
                                        <option value="date">date</option>
                                        <option value="time">time</option>
                                        <option value="area">area</option>
                                        <option value="script">script</option>
                                        <option value="password">password</option>
                                        <option value="hidden">hidden</option>
                                    </select>
                                </div>
                                <div class="col-5">
                                    <small>Baris</small>
                                    <input type="number" class="form-control" id="row" name="row" required>
                                </div>
                            </div>

                            <div class="col-12">
                                <small>Sync</small>
                                <div class="row col">
                                    <div class="col-6">
                                        <input type="radio" name="sync" id="sync1" class="mr-2" value="">Optional
                                    </div>
                                    <div class="col-6">
                                        <input type="radio" name="sync" id="sync2" class="mr-2" value="required">Wajib
                                    </div>
                                    <div class="col-6">
                                        <input type="radio" name="sync" id="sync3" class="mr-2" value="readonly">Readonly
                                    </div>
                                    <div class="col-6">
                                        <input type="radio" name="sync" id="sync4" class="mr-2" value="hidden">Hidden
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">

                            <div class="col-12">
                                <small>Status</small>
                                <div class="row col">
                                    <div class="col-6">
                                        <input type="radio" name="status" id="status1" class="mr-2" value="true">Enable
                                    </div>
                                    <div class="col-6">
                                        <input type="radio" name="status" id="status2" class="mr-2" value="false">Disable
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <small>Class</small>
                                <input type="text" class="form-control" id="class" name="class" required>
                            </div>
                            <div class="col-12">
                                <small>Style</small>
                                <input type="text" class="form-control" id="style" name="style">
                            </div>
                            <div class="col-12">
                                <small>Script</small>
                                <textarea name="script" id="script" cols="30" rows="2" class="form-control"></textarea>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <a href="javascript:void(0)" onclick="save2();" class="btn btn-outline-dark btn-sm"><i class="fa fa-save mr-2"></i>Save</a>
            </div>
        </div>
    </div>
</div>
<!-- End Modal 2-->
<!-- Start Modal 1 -->
<div class="modal fade" id="modal2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <div id="head2"></div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="col-12">

                </div>
            </div>
            <div class="modal-footer">
            </div>
        </div>
    </div>
</div>
<!-- End Modal 1-->
<script type="text/javascript">
    $('#a3').hide();
    setTimeout(hide1, 2000)
    //-----------------------------------------start
    function hide1() {
        document.getElementById('aks').value = '';
        document.getElementById('lb1').innerHTML = '';
        document.getElementById('lb2').innerHTML = '';
        $('#a3').hide();
        $('#a2').hide();
        $('#a1').show();
        $('#dguser').datagrid('reload');
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function hide2() {
        document.getElementById('lb3').innerHTML = '';
        document.getElementById('lb4').innerHTML = '';
        $('#a3').hide();
        $('#a2').hide();
        $('#a1').show();
        $('#dguser').datagrid('reload');
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function barschema() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            document.getElementById('aks').value = row.akses;
            document.getElementById('lb1').innerHTML = 'AKSES NAME : ' + row.level_name + '.' + row.akses_name;
            document.getElementById('lb2').innerHTML = 'AKSES ID : ' + row.akses;
            $('#a1').hide();
            $('#a3').hide();
            $('#a2').show();
            $('#dguser2').datagrid({
                url: '<?= XROOT ?>init/get_sidebar'
            });
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function ischema() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            document.getElementById('lb3').innerHTML = 'LEVEL NAME : ' + row.level_name;
            document.getElementById('lb4').innerHTML = 'DATABASE : ' + row.level;
            document.getElementById('lvl').value = row.level;
            $('#a1').hide();
            $('#a2').hide();
            $('#a3').show();
            $('#dguser3').datagrid({
                url: '<?= XROOT ?>init/get_schema/' + row.level + '/1'
            });
            $('#dguser4').datagrid({
                url: '<?= XROOT ?>init/get_schema/' + row.level + '/2'
            });
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function barschema() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            document.getElementById('aks').value = row.akses;
            document.getElementById('lb1').innerHTML = 'AKSES NAME : ' + row.level_name + '.' + row.akses_name;
            document.getElementById('lb2').innerHTML = 'AKSES ID : ' + row.akses;
            $('#a1').hide();
            $('#a3').hide();
            $('#a2').show();
            $('#dguser2').datagrid('reload');
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function add() {
        $('#fm').form('clear');
        document.getElementById('level_name').readOnly = false;
        document.getElementById('grup').readOnly = false;
        document.getElementById('no').value = '0';
        document.getElementById('no').readOnly = true;
        document.getElementById("head").innerHTML = '<h5 class="modal-title"><i class="fa fa-plus mr-2"></i>Tambah Data</h5>';
        document.getElementById("id").value = 'insert';
        $('#modal').modal('show');
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function add2() {
        $('#fm2').form('clear');
        document.getElementById('group1').checked = true;
        document.getElementById('sync1').checked = true;
        document.getElementById('status1').checked = true;
        document.getElementById('type').value = 'text';
        document.getElementById('row').value = '10';
        document.getElementById("head2").innerHTML = '<h5 class="modal-title"><i class="fa fa-plus mr-2"></i>Tambah Data</h5>';
        document.getElementById("id2").value = 'insert';
        $('#modal2').modal('show');
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function adds() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $('#fm').form('load', row);
            document.getElementById('level_name').readOnly = true;
            document.getElementById('grup').readOnly = true;
            document.getElementById('no').value = '1';
            document.getElementById('no').readOnly = false;
            document.getElementById("head").innerHTML = '<h5 class="modal-title"><i class="fa fa-plus mr-2"></i>Tambah Sub Akses</h5>';
            document.getElementById("akses_name").value = '';
            document.getElementById("id").value = 'addsub';
            $('#modal').modal('show');
        } else {
            $.messager.show({ // show error message
                title: 'Error',
                msg: 'Data tidak di pilih'
            });
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function update() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $('#fm').form('load', row);
            if (row.role == 'SUB_AKSES') {
                document.getElementById('no').readOnly = false;
                document.getElementById('level_name').readOnly = true;
                document.getElementById('grup').readOnly = true;
            } else {
                document.getElementById('no').readOnly = true;
                document.getElementById('level_name').readOnly = false;
                document.getElementById('grup').readOnly = false;
            }
            document.getElementById("head").innerHTML = '<h5 class="modal-title"><i class="fa fa-edit mr-2"></i>Edit Data</h5>';
            $('#modal').modal('show');
        } else {
            $.messager.show({ // show error message
                title: 'Error',
                msg: 'Data tidak di pilih'
            });
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function upschema(val) {
        var row = $('#dguser' + val).datagrid('getSelected');
        if (row) {
            $('#fm2').form('load', row);
            document.getElementById("head2").innerHTML = '<h5 class="modal-title"><i class="fa fa-edit mr-2"></i>Edit Data</h5>';
            $('#modal2').modal('show');
        } else {
            $.messager.show({ // show error message
                title: 'Error',
                msg: 'Data tidak di pilih'
            });
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function save() {
        if (document.getElementById('grup').value == '') {
            $.messager.show({
                title: 'Error',
                msg: 'Group harus di isi'
            });
            exit;
        }
        if (document.getElementById('level_name').value == '') {
            $.messager.show({
                title: 'Error',
                msg: 'Level Name harus di isi'
            });
            exit;
        }
        if (document.getElementById('akses_name').value == '') {
            $.messager.show({
                title: 'Error',
                msg: 'Akses Name harus di isi'
            });
            exit;
        }
        $('#fm').form('submit', {
            url: '<?= XROOT ?>init/crud_engine',
            onSubmit: function() {
                return $(this).form('validate');
            },
            success: function(result) {
                var result = eval('(' + result + ')');
                if (result.errorMsg) {
                    $.messager.show({
                        title: 'Error',
                        msg: result.errorMsg
                    });
                } else {
                    $('#modal').modal('hide');
                    $('#dguser').datagrid('reload');
                    $.messager.show({
                        title: 'Success !',
                        msg: 'Berhasil'
                    });

                }
            }
        });
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function save2() {
        var lvl = document.getElementById('lvl').value;
        if (document.getElementById('label').value == '') {
            $.messager.show({
                title: 'Error',
                msg: 'Label harus di isi'
            });
            exit;
        }
        if (document.getElementById('type').value == '') {
            $.messager.show({
                title: 'Error',
                msg: 'Type harus di pilih'
            });
            exit;
        }
        if (document.getElementById('row').value == '') {
            $.messager.show({
                title: 'Error',
                msg: 'Baris harus di isi'
            });
            exit;
        }
        if (document.getElementById('class').value == '') {
            document.getElementById('class').value = 'form-control';
        }
        $('#fm2').form('submit', {
            url: '<?= XROOT ?>init/crud_sch/' + lvl,
            onSubmit: function() {
                return $(this).form('validate');
            },
            success: function(result) {
                var result = eval('(' + result + ')');
                if (result.errorMsg) {
                    $.messager.show({
                        title: 'Error',
                        msg: result.errorMsg
                    });
                } else {
                    $('#modal2').modal('hide');
                    $('#dguser3').datagrid('reload');
                    $('#dguser4').datagrid('reload');
                    $.messager.show({
                        title: 'Success !',
                        msg: 'Berhasil'
                    });

                }
            }
        });
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function destroyuser() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $.messager.confirm('Attention!', '<strong class="text-danger">Hati-hati Melakukan aksi ini,</strong><br> Apakah Anda Yakin Ingin Menghapus data ini ?<br>Level name : ' + row.level_name + '<br>Akses name : ' + row.akses_name, function(r) {
                if (r) {
                    if (row.role == 'DEFAULT_AKSES') {
                        url = '<?= XROOT ?>init/delg_engine';
                        grup = row.grup;
                        id = row.id;
                    } else {
                        url = '<?= XROOT ?>init/del_engine';
                        grup = '';
                        id = row.id;
                    }
                    $.post(url, {
                        id,
                        grup
                    }, function(result) {
                        if (result.success) {
                            $('#dguser').datagrid('reload'); // reload the Vendor data
                            $.messager.show({ // show error message
                                title: 'Success !',
                                msg: 'Berhasil Di Hapus'
                            });
                        } else {
                            $.messager.show({ // show error message
                                title: 'Error',
                                msg: result.errorMsg
                            });
                        }
                    }, 'json');
                }
            });
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function delschema(val) {
        var lvl = document.getElementById('lvl').value;
        var row = $('#dguser' + val).datagrid('getSelected');
        if (row) {
            if (row.r == '1') {
                $.messager.show({ // show error message
                    title: 'Error',
                    msg: 'Input default tidak boleh di hapus'
                });
                exit;
            }
            $.messager.confirm('Attention!', '<strong class="text-danger">Hati-hati Melakukan aksi ini,</strong><br> Apakah Anda Yakin Ingin Menghapus data ini ?<br>Label : ' + row.label + '<br>Type : ' + row.type, function(r) {
                if (r) {
                    url = '<?= XROOT ?>init/del_schema/' + lvl;
                    id = row.id;
                    $.post(url, {
                        id
                    }, function(result) {
                        if (result.success) {
                            $('#dguser3').datagrid('reload'); // reload the Vendor data
                            $('#dguser4').datagrid('reload'); // reload the Vendor data
                            $.messager.show({ // show error message
                                title: 'Success !',
                                msg: 'Berhasil Di Hapus'
                            });
                        } else {
                            $.messager.show({ // show error message
                                title: 'Error',
                                msg: result.errorMsg
                            });
                        }
                    }, 'json');
                }
            });
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function show_grup(val, row) {
        for (var name in row) {
            if (row.role == 'SUB_AKSES') {
                var t = '';
            } else {
                var t = row.grup;
            }
            if (row["pur_grup"] == "Received") {} else {
                return t;
            }
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function show_lvln(val, row) {
        for (var name in row) {
            if (row.role == 'SUB_AKSES') {
                var t = '';
            } else {
                var t = row.level_name;
            }
            if (row["pur_lvln"] == "Received") {} else {
                return t;
            }
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function show_lvl(val, row) {
        for (var name in row) {
            if (row.role == 'SUB_AKSES') {
                var t = '<strong class="float-right">' + row.no + '</strong>';
            } else {
                var t = row.level;
            }
            if (row["pur_lvl"] == "Received") {} else {
                return t;
            }
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function show_akses(val, row) {
        for (var name in row) {
            var t = row.level_name + '.' + row.akses_name;
            if (row["pur_akses"] == "Received") {} else {
                return t;
            }
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function show_sc(val, row) {
        for (var name in row) {
            if (row.status == 'true') {
                $cek = '';
            } else {
                $cek = 'bg-danger text-white';
            }
            t = '<div class="card col table-responsive ' + $cek + '">';
            t += row.row + '. ' + row.label + '<br> [' + row.sync + '] [' + row.type + '] [' + row.class + '] <br>';
            if (row.type == 'script') {
                t += row.script;
            } else if (row.type == 'select') {
                t += 'Script : Select -> ' + row.script + '<br>';
            } else if (row.type == 'area') {
                t += `<textarea name="` + row.id + `" id="` + row.id + `" cols="30" rows="2" class="` + row.class + `" style="` + row.style + `" ` + row.sync + `></textarea>`;
            } else {
                t += `<input type="` + row.type + `" class="` + row.class + `" style="` + row.style + `" id="` + row.id + `" name="` + row.id + `" ` + row.sync + `>`;
            }
            t += '<br>';
            t += '</div>';
            if (row["pur_sc"] == "Received") {} else {
                return t;
            }
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function show_col1(val, row) {
        for (var name in row) {
            var aks = document.getElementById('aks').value;
            if (row[aks] == '1') {
                if (row.colum == '1') {
                    (row.role == '0') ? bg = 'bg-2': bg = 'bg-1';
                    var t = '<div class="card col table-responsive ' + bg + '"><o><i class="' + row.icon + ' mr-2 ml-2" title="' + row.ket + '"></i>' + row.nama + '</o></div>';
                } else {
                    var t = '';
                }
                if (row["pur_col1"] == "Received") {} else {
                    return t;
                }
            } else {
                if (row.colum == '1') {
                    var t = '<div class="card col table-responsive"><o><i class="' + row.icon + ' mr-2 ml-2" title="' + row.ket + '"></i>' + row.nama + '</o></div>';
                } else {
                    var t = '';
                }
                if (row["pur_col1"] == "Received") {} else {
                    return t;
                }
            }
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function show_col2(val, row) {
        for (var name in row) {
            var aks = document.getElementById('aks').value;
            if (row[aks] == '1') {
                if (row.colum == '2') {
                    (row.role == '0') ? bg = 'bg-2': bg = 'bg-1';
                    var t = '<div class="card col table-responsive ' + bg + '"><o><i class="' + row.icon + ' mr-2 ml-2" title="' + row.ket + '"></i>' + row.nama + '</o></div>';
                } else {
                    var t = '';
                }
                if (row["pur_col2"] == "Received") {} else {
                    return t;
                }
            } else {
                if (row.colum == '2') {
                    var t = '<div class="card col table-responsive"><o><i class="' + row.icon + ' mr-2 ml-2" title="' + row.ket + '"></i>' + row.nama + '</o></div>';
                } else {
                    var t = '';
                }
                if (row["pur_col2"] == "Received") {} else {
                    return t;
                }
            }
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function show_col3(val, row) {
        for (var name in row) {
            var aks = document.getElementById('aks').value;
            if (row[aks] == '1') {
                if (row.colum == '3') {
                    (row.role == '0') ? bg = 'bg-2': bg = 'bg-1';
                    var t = '<div class="card col table-responsive ' + bg + '"><o><i class="' + row.icon + ' mr-2 ml-2" title="' + row.ket + '"></i>' + row.nama + '</o></div>';
                } else {
                    var t = '';
                }
                if (row["pur_col3"] == "Received") {} else {
                    return t;
                }
            } else {
                if (row.colum == '3') {
                    var t = '<div class="card col table-responsive"><o><i class="' + row.icon + ' mr-2 ml-2" title="' + row.ket + '"></i>' + row.nama + '</o></div>';
                } else {
                    var t = '';
                }
                if (row["pur_col3"] == "Received") {} else {
                    return t;
                }
            }
        }
    }
    //-----------------------------------------end

    //-----------------------------------------start
    $(function() {
        $('#dguser').datagrid({
            singleSelect: true,
            onRowContextMenu: function(e, index, row) {
                $(this).datagrid('selectRow', index);
                e.preventDefault();
                if (row.level != 'modul' && row.level != 'admin_pusat') {
                    document.getElementById('btdel').innerHTML = '<a href="javascript:void(0)" class="btn-sm form-control" plain="true" onClick="destroyuser();"><i class="fa fa-trash mr-2 text-danger"></i> Hapus</a>';
                    if (row.role == 'DEFAULT_AKSES') {
                        document.getElementById('subakses').innerHTML = '<a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="adds();"><i class="fa fa-plus mr-2"></i> Sub Akses</a>';
                        document.getElementById('btschema').innerHTML = '<a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="ischema();"><i class="fab fa-hubspot mr-2"></i> Input Schema</a>';
                    } else {
                        document.getElementById('subakses').innerHTML = '';
                        document.getElementById('btschema').innerHTML = '';
                    }
                } else {
                    document.getElementById('btdel').innerHTML = '';
                    document.getElementById('subakses').innerHTML = '';
                    document.getElementById('btschema').innerHTML = '';
                }
                $('#mm').menu('show', {
                    left: e.pageX,
                    top: e.pageY
                });
            },
            onDblClickRow: function() {
                barschema();
            },
            rowStyler: function(index, row) {
                if (row.role == 'DEFAULT_AKSES') {
                    return 'font-weight:bold;';
                }
            }

        })

    })
    //-----------------------------------------end
    //-----------------------------------------start
    $(function() {
        $('#dguser2').datagrid({
            singleSelect: true,
            onRowContextMenu: function(e, index, row) {
                $(this).datagrid('selectRow', index);
                e.preventDefault();
                $.messager.show({ // show error message
                    title: 'Error',
                    msg: 'Fungsi Tidak Tersedia'
                });
            },
            onDblClickRow: function() {
                var aks = document.getElementById('aks').value;
                var row = $('#dguser2').datagrid('getSelected');
                if (row) {
                    url = '<?= XROOT ?>init/e_sidebar';
                    $.post(url, {
                        id: row.id,
                        aks
                    }, function(result) {
                        if (result.success) {
                            $('#dguser2').datagrid('reload');
                        } else {
                            $.messager.show({ // show error message
                                title: 'Error',
                                msg: result.errorMsg
                            });
                        }
                    }, 'json');
                }
            },
            rowStyler: function(index, row) {
                // ..............
            }

        })

    })
    //-----------------------------------------end
    //-----------------------------------------start
    $(function() {
        $('#dguser3').datagrid({
            singleSelect: true,
            onRowContextMenu: function(e, index, row) {
                $(this).datagrid('selectRow', index);
                e.preventDefault();
                if (row.r == '1') {
                    $('#bth3').html(``);
                } else {
                    $('#bth3').html(`<a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="delschema('3');"><i class="fa fa-trash text-danger mr-2"></i> Hapus</a>`);
                }
                $('#mm3').menu('show', {
                    left: e.pageX,
                    top: e.pageY
                });
            },
            onDblClickRow: function() {
                // ...........
            },
            rowStyler: function(index, row) {
                // ..............
            }

        })

    })
    //-----------------------------------------end
    //-----------------------------------------start
    $(function() {
        $('#dguser4').datagrid({
            singleSelect: true,
            onRowContextMenu: function(e, index, row) {
                $(this).datagrid('selectRow', index);
                e.preventDefault();
                if (row.r == '1') {
                    $('#bth4').html(``);
                } else {
                    $('#bth4').html(`<a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="delschema('4');"><i class="fa fa-trash text-danger mr-2"></i> Hapus</a>`);
                }
                $('#mm4').menu('show', {
                    left: e.pageX,
                    top: e.pageY
                });
            },
            onDblClickRow: function() {
                // ...........
            },
            rowStyler: function(index, row) {
                // ..............
            }

        })

    })
    //-----------------------------------------end
</script>