<script type="text/javascript">
    //=============================
    if ('<?= session()->getFlashdata('info'); ?>' == '') {} else {
        $.messager.show({
            title: 'Success',
            msg: '<?= session()->getFlashdata('info'); ?>'
        });
    }
    if ('<?= session()->getFlashdata('error'); ?>' == '') {} else {
        $.messager.show({
            title: 'Error',
            msg: '<?= session()->getFlashdata('error'); ?>'
        });
    }
    //=============================
    //-----------------------------------------start
    function msg(t, msg) {
        $.messager.show({
            title: t,
            msg: msg
        });
    }
    //-----------------------------------------end
</script>
</body>
<!--START Modal 1-->
<div class="modal fade" id="load" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <br>
        <br>
        <br>
        <br>
        <center>
            <img src="<?= XROOT ?>img/dev/loading.gif" width="140">
        </center>
    </div>
</div>
<!-- End Modal 1-->

</html>