<footer class="main-footer">
    <strong>Copyright &copy; <?= date("Y") ?> <a href="<?= XROOT ?>" target="_blank"><?= inc('nama-instansi') ?></a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Tanggal</b> <?= date("d M Y") ?>
    </div>
</footer>

<script src="<?= XROOT ?>script/jquery/jquery.min.js"></script>
<script src="<?= XROOT ?>script/jquery-ui/jquery-ui.min.js"></script>
<script src="<?= XROOT ?>script/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?= XROOT ?>script/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<script src="<?= XROOT ?>script/toastr/toastr.min.js"></script>
<script src="<?= XROOT ?>script/lte/js/adminlte.js"></script>
<script src="<?= XROOT ?>script/owlcarousel/owl.carousel.min.js"></script>
<script type="text/javascript">
    //=============================
    if ('<?= session()->getFlashdata('info'); ?>' == '') {} else {
        toastr.success('<?= session()->getFlashdata('info'); ?>')
    }
    if ('<?= session()->getFlashdata('error'); ?>' == '') {} else {
        toastr.error('<?= session()->getFlashdata('error'); ?>')
    }
    //=============================
</script>
</body>
<!--START Modal 1-->
<div class="modal fade" id="load" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <br>
        <br>
        <br>
        <br>
        <center>
            <img src="<?= XROOT ?>img/dev/loading.gif" width="140">
        </center>
    </div>
</div>
<!-- End Modal 1-->
<script src="<?= XROOT ?>script/modal.js"></script>
<script>
    $.widget.bridge("uibutton", $.ui.button);
</script>

<!-- QRCODE STYLE START -->
<script src="<?= XROOT ?>script/qr-code-styling.js"></script>
<script src="<?= XROOT ?>script/show_qr.js"></script>
<script type="text/javascript">
    cek_lock("<?= session()->get('locked') ?>")
    var status = "<?= inc('playstore-status') ?>";
    var color = '<?= color('qrcode-a') ?>';
    if (status == 'true') {
        var data = "<?= inc('playstore-url') ?>";
        var logo = "<?= XROOT ?>img/instansi/<?= inc('playstore-logo') ?>";
        qrcode("play_store", data, logo, color);
    } else {
        var data = "<?= XURL ?>";
        var logo = "<?= XROOT ?>img/instansi/<?= inc('logo-n') ?>";
        qrcode("qrmain", data, logo, color);
    }
</script>
<!-- QRCODE STYLE END -->