<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title><?= $title ?></title>
    <link rel="icon" type="image/x-icon" href="<?= XROOT ?>img/instansi/<?= inc('logo') ?>" />
    <link href="<?= XROOT ?>script/web2/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= XROOT ?>script/web2/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?= XROOT ?>script/web2/css/prettyPhoto.css" rel="stylesheet">
    <link href="<?= XROOT ?>script/web2/css/price-range.css" rel="stylesheet">
    <link href="<?= XROOT ?>script/web2/css/animate.css" rel="stylesheet">
    <link href="<?= XROOT ?>script/web2/css/main.css" rel="stylesheet">
    <link href="<?= XROOT ?>script/web2/css/responsive.css" rel="stylesheet">
</head>
<!--/head-->

<body>
    <header id="header" class="wid-t">
        <!--header-->
        <div class="header_top">
            <!--header_top-->
            <div class="container">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="contactinfo">
                            <ul class="nav nav-pills">
                                <li><a href="#"><i class="fa fa-phone"></i> <?= inc('telp') ?></a></li>
                                <li><a href="#"><i class="fa fa-envelope"></i> <?= inc('email') ?></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="social-icons pull-right">
                            <ul class="nav navbar-nav">
                                <?php
                                if (inc('url_facebook') != null) {
                                    echo '<li><a href="' . inc('url_facebook') . '" target="_blank"><i class="fa fa-facebook"></i></a></li>';
                                }
                                if (inc('url_instagram') != null) {
                                    echo '<li><a href="' . inc('url_instagram') . '" target="_blank"><i class="fa fa-instagram"></i></a></li>';
                                }
                                ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--/header_top-->
        <?php
        $l1 =  substr(inc('app-name'), 0, 1);
        $l2 =  str_replace($l1, "", inc('app-name'));
        ?>
        <div class="header-middle" style="background-color: #fff;">
            <!--header-middle-->
            <div class="container">
                <div class="row">
                    <div class="col-sm-4">
                        <div class="shop-menu pull-left">
                            <a href=""><img src="<?= XROOT ?>img/instansi/<?= inc('logo') ?>" style="margin: left 10px;" alt="" width="60" />
                                <div class="btn-group pull-right">
                                    <div class="maintext">
                                        <h2><small><strong><span> <?= $l1 ?></span><?= $l2 ?></strong></small></h2>
                                        <p><small><strong> <?= inc('app-name-2') ?></strong></small></p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-sm-8">
                        <div class="shop-menu pull-right">
                            <ul class="nav navbar-nav">
                                <li><a href="<?= XROOT ?>web/login"><i class="fa fa-lock"></i> Login</a></li>
                            </ul>
                        </div>
                        <?php
                        $page = session()->get('page');
                        if ($page == 'member') {
                            echo ' <div class="shop-menu pull-right">
                            <ul class="nav navbar-nav">
                                <li><a href="' . XROOT . '"><i class="fa fa-home"></i> Home</a></li>
                            </ul>
                        </div>';
                        } else {
                            echo ' <div class="shop-menu pull-right">
                            <ul class="nav navbar-nav">
                                <li><a href="' . XROOT . 'web/member"><i class="fa fa-user"></i> Member List</a></li>
                            </ul>
                        </div>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
        <!--/header-middle-->
    </header>