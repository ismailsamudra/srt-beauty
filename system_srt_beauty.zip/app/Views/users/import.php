<!-- TOP NAVIGASI START -->
<link rel="stylesheet" href="<?= XROOT ?>script/crop/croppie.css">
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <?php btback() ?>
        <a href="javascript:void(0);" onclick="add()" class="btn-sm bt-1 float-left" title="EDIT"><i class="fa fa-user-plus"></i></a>
        <a href="" style="color: <?= color('primary-b') ?>;">
            <small>
                <strong>
                    <i class="far fa-user mr-2"></i> TABLE USERS IMPORT
                </strong>
            </small>
        </a>
        <a href="javascript:void(0);" onclick="$('#dguser').datagrid('reload');" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
        <a href="javascript:void(0);" onclick="manual()" class="btn-sm bt-1 float-right mr-2" title="Import"><i class="fa fa-file-excel"></i></a>
    </center>

</div>

<!-- TOP NAVIGASI END -->
<style>
    .image_upload>input {
        display: none;
    }

    /* input[type=text]{width:220px;height:auto;} */
</style>
<?php
if ($id == inc('level_regist')) {
    $td1 = '<th field="no_rm" sortable="true" align="center">No.RM</th>';
}
?>
<!-- BODY START -->
<div class="m-1">
    <div class="col-md-12 table-responsive">
        <center>
            <table id="dguser" toolbar="#toolbarCustomer" class="easyui-datagrid" singleSelect="true" style="width: 100%;height: 400px;" fitColumns="true" rowNumbers="false" pagination="true" url="<?= XROOT ?>users/get_import" pageSize="10" pageList="[10,25,50,75,100,125,150,200]">
                <thead>
                    <tr>
                        <th field="pur_foto" formatter="show_foto" align="center">Foto</th>
                        <th field="nama" width="200" sortable="true">Nama</th>
                        <th field="email" sortable="true">Email</th>
                        <th field="hp" sortable="true">No.HP/WA</th>
                        <th field="nik" sortable="true">NIK</th>
                        <th field="tanggal_lahir" sortable="true">Tgl_Lahir</th>
                        <th field="jk" sortable="true" align="center">JK</th>

                    </tr>
                </thead>
            </table>
        </center>
    </div>
</div>
<!-- BODY END -->
<div id="toolbarCustomer">
    <div class="row">
        <div class="col-md-3">
            <!---------SEARCH BOX START--------->
            <input id="searchCustomer" class="easyui-searchbox" data-options="prompt:'Cari..',searcher:doSearchCustomer,
            inputEvents: $.extend({}, $.fn.searchbox.defaults.inputEvents, {
                keyup: function(e){
                    var t = $(e.data.target);
                    var opts = t.searchbox('options');
                    t.searchbox('setValue', $(this).val());
                    opts.searcher.call(t[0],t.searchbox('getValue'),t.searchbox('getName'));
                }
            })
        " style="width:100%;"></input>
            <!---------SEARCH BOX END----------->
        </div>
    </div>
</div>
<div id="mm" class="easyui-menu">
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="change_foto();"><i class="fa fa-images mr-2"></i> Ganti Foto</a>
    <a id="btnwa"></a>
    <a id="btnwar"></a>
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="update();"><i class="far fa-edit mr-2"></i> Edit</a>
    <a href="javascript:void(0)" class="btn-sm form-control" plain="true" onClick="destroyuser('del');"><i class="fa fa-trash mr-2 text-danger"></i> Hapus</a>
</div>

<!-- Start Modal 1 -->
<div class="modal fade" id="modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div id="head"></div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="fm" method="post">
                    <input type="hidden" id="id" name="id">
                    <input type="hidden" id="action" name="action">
                    <small>Nama Lengkap <small>[Wajib]</small></small>
                    <input type="text" class="form-control" name="nama" id="nama">
                    <small>Email <small>[Wajib]</small></small>
                    <input type="text" class="form-control" name="email" id="email">
                    <small>No.Hp/Wa <small>[Wajib]</small></small>
                    <input type="text" class="form-control" name="hp" id="hp">
                    <small>Tanggal Lahir <small>[Wajib]</small></small>
                    <input type="date" class="form-control" name="tanggal_lahir" id="tanggal_lahir">
                    <small>NIK <small>[Optional]</small></small>
                    <input type="text" class="form-control" name="nik" id="nik">
                    <small>Alamat <small>[Optional]</small></small>
                    <textarea name="alamat" id="alamat" cols="30" rows="2" class="form-control"></textarea>
                    <small>Jenis Kelamin</small>
                    <div class="row col">
                        <div class="col-md-6">
                            <input type="radio" name="jk" id="jk1" onclick="" class="mr-2" value="L">Laki -Laki
                        </div>
                        <div class="col-md-6">
                            <input type="radio" name="jk" id="jk2" onclick="" class="mr-2" value="P">Perempuan
                        </div>
                    </div>


                </form>

            </div>
            <div class="modal-footer">
                <a href="javascript:void(0)" onclick="save();" class="btn btn-outline-dark btn-sm"><i class="fa fa-save mr-2"></i>Save</a>
            </div>


        </div>
    </div>
</div>
<!-- End Modal 1-->
<?php
if (inc('wa_status') == 'true') {
    echo '
        <script type="text/javascript">
        $("#btnwar").html(`
        <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="wa_kuisioner();"><i class="far fa-thumbs-up mr-2"></i>Wa Kuisioner</a>
        `); 
        //-----------------------------------------start
        function wa_kuisioner() {
            var row = $("#dguser").datagrid("getSelected");
            if (row) {
                $.messager.confirm("Attention!", "<strong>Hati-hati Melakukan aksi ini,</strong><br> Apakah Anda Yakin Ingin Mengirim Kuisioner Wa Ke user ini ?<br>Nama : " + row.nama + " <br> No.Wa : " + row.hp  ,
                    function(r) {
                        if (r) {
                            $("#load").modal({
                                backdrop: "static",
                                keyboard: false
                            });
                            var to = row.hp;
                            var text_msg = `' . inc("wa_kuisioner_text") . '`;
                            if(text_msg==""){
                                $.messager.show({ // show error message
                                    title: "Gagal !!!",
                                    msg: "Text Pesan Belum Di Setting."
                                });
                                exit;
                            }
                            var msg = text_msg.replace("#NAMA#", row.nama);
                            $.post("' . XROOT . 'whatsapp/send", {
                                to,
                                msg
                            }, function(result) {
                                $("#load").modal("hide");
                                if (result.success) {
                                    $("#dguser").datagrid("reload"); // reload the Vendor data
                                    $.messager.show({ // show error message
                                        title: "Success !",
                                        msg: "Pesan berhasil di kirim"
                                    });
                                    $("#whatsapp").modal("hide");
                                } else {
                                    $.messager.show({ // show error message
                                        title: "Gagal !!!",
                                        msg: result.errorMsg
                                    });
                                }
                            }, "json");
                        }
                    });
            } else {
                $.messager.show({ // show error message
                    title: "Error",
                    msg: "Data tidak di pilih"
                });
            }
        }
        //-----------------------------------------end
        </script>
        ';
    echo '
    <!-- Start Modal Whatsapp -->
<div class="modal fade" id="whatsapp" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fab fa-whatsapp mr-2"></i>Kirim Whatsapp</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="fm2" method="post">
                    Nama
                    <input type="text" name="nama" id="nama" class="form-control" readonly>
                    No.Whatsapp
                    <input type="text" name="hp" id="nohp" class="form-control" readonly>
                    Pesan
                    <textarea name="text" id="text" cols="30" rows="4" class="form-control" required></textarea>
                </form>
                <div class="container">
                    <div class="text-danger">
                        <strong>
                            Attention !
                        </strong><br>
                        Aksi ini membutuhkan koneksi server whatsapp.
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <a href="javascript:void(0)" onclick="send();" class="btn btn-outline-dark btn-sm"><i class="fa fa-paper-plane mr-2"></i>Kirim</a>
            </div>

        </div>
    </div>
</div>
<script type="text/javascript">
    $("#btnwa").html(`
    <a href="javascript:void(0)" class="btn-sm form-control mb-1" plain="true" onClick="wa();"><i class="fab fa-whatsapp mr-2"></i>Whatsapp</a>
    `);
    //-----------------------------------------start
    function wa() {
        var row = $("#dguser").datagrid("getSelected");
        if (row) {
            $("#fm2").form("load", row);
            document.getElementById("text").value = "";
            $("#whatsapp").modal("show");
        } else {
            $.messager.show({ // show error message
                title: "Error",
                msg: "Data tidak di pilih"
            });
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function send() {
        var to = document.getElementById("nohp").value;
        var msg = document.getElementById("text").value;
        if (msg == "") {
            $.messager.show({ // show error message
                title: "Error",
                msg: "Kolom Pesan Belum di isi."
            });
           $("#text").focus();
            exit;
        }
        $("#load").modal({
            backdrop: "static",
            keyboard: false
        });
        $.post("' . XROOT . 'whatsapp/send", {
            to,
            msg
        }, function(result) {
            $("#load").modal("hide");
            if (result.success) {
                $("#dguser").datagrid("reload"); // reload the Vendor data
                $.messager.show({ // show error message
                    title: "Success !",
                    msg: "Pesan berhasil di kirim"
                });
                $("#whatsapp").modal("hide");
            } else {
                $.messager.show({ // show error message
                    title: "Gagal !!!",
                    msg: result.errorMsg
                });
            }
        }, "json");
    }
    //-----------------------------------------end
</script>
<!-- End Modal Whatsapp-->
    ';
}
?>
<!-- Start Modal 1 -->
<div class="modal fade" id="manual" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fa fa-file-excel mr-2"></i>Import CSV</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <small>Only CSV</small>
                <input type="file" name="file" id="file" class="form-control">
            </div>
            <div class="modal-footer">
                <a href="<?= XURL ?>csvfile/temp_users_import.csv" target="_blank" class="btn btn-outline-success btn-sm mr-2"><i class="fa fa-download mr-2"></i>Template</a>
                <a href="javascript:void(0)" onclick="upload();" class="btn btn-outline-dark btn-sm"><i class="fa fa-upload mr-2"></i>Upload</a>
            </div>
        </div>

    </div>
</div>
</div>
<!-- End Modal 1-->
<!-- Start Modal 1 -->
<div class="modal fade" id="foto" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <a onclick="cmod();" class="btn" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </a>
            <div id="cont1" class="container my-3">
                <input type="file" id="upload_image" class="form-control" accept="image/*">
            </div>
            <div id="cont2" class="container mty-3">
                <a class="btn btn-outline-primary btn-sm crop_image d-block"> <i class="fa fa-crop mr-2"></i>Crop & Upload</a>
            </div>
            <div id="temp_foto"></div>
        </div>
    </div>
</div>
<!-- End Modal 1-->
<!--START Modal 1-->
<div class="modal fade" id="load" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <br>
        <br>
        <br>
        <br>
        <center>
            <img src="<?= XROOT ?>img/dev/loading.gif" width="140">
        </center>
    </div>
</div>
<!-- End Modal 1-->
<!---------------------------croppie start--------------------------------->
<script src="<?= XROOT ?>script/crop/croppie.min.js"></script>
<!---------------------------croppie end----------------------------------->
<script type="text/javascript">
    //-----------------------------------------end
    function upload() {
        var url = '<?= XROOT ?>users/up_csv';
        var property = document.getElementById('file').files[0];
        var image_name = property.name;
        var image_extension = image_name.split('.').pop().toLowerCase();
        var e = image_extension;
        if (e !== 'csv') {
            toastr.error('File Extensi Harus [ csv ].');
            exit;
        }
        var form_data = new FormData();
        form_data.append("file", property);

        $.ajax({
            url: url,
            method: 'POST',
            data: form_data,
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                $('#manual').modal('hide');
                toastr.success('Berhasil Di Import. <br>' + data);
                $('#dguser').datagrid('reload');
            }
        });
    }
    //-----------------------------------------start
    //-----------------------------------------start
    function manual() {
        $('#manual').modal('show');
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function cmod() {
        $('#foto').modal('hide');
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function doSearchCustomer() {
        $('#dguser').datagrid('load', {
            search_customer: $('#searchCustomer').val()
        });
    }
    //-----------------------------------------end

    //-----------------------------------------start
    function add() {
        $('#fm').form('clear');
        document.getElementById("jk1").checked = true;
        document.getElementById("head").innerHTML = '<h5 class="modal-title"><i class="fa fa-plus mr-2"></i>Tambah Data</h5>';
        document.getElementById("id").value = 'insert';
        $('#modal').modal('show');

    }
    //-----------------------------------------end
    //-----------------------------------------start
    function update() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $('#fm').form('load', row);
            // document.getElementById("akses").value = row.akses;
            document.getElementById("head").innerHTML = '<h5 class="modal-title"><i class="fa fa-edit mr-2"></i>Edit Data</h5>';
            $('#modal').modal('show');
        } else {
            $.messager.show({ // show error message
                title: 'Error',
                msg: 'Data tidak di pilih'
            });
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function save() {
        var nama = document.getElementById("nama").value;
        if (nama == '') {
            $.messager.show({ // show error message
                title: 'Error',
                msg: 'Data nama Belum Di isi.'
            });
            $('#nama').focus();
            exit;
        }
        var email = document.getElementById("email").value;
        if (email == '') {
            $.messager.show({ // show error message
                title: 'Error',
                msg: 'Data email Belum Di isi.'
            });
            $('#email').focus();
            exit;
        }
        var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        if (!email.match(mailformat)) {
            $.messager.show({ // show error message
                title: 'Error',
                msg: 'Format Email Salah.'
            });
            $('#email').focus();
            exit;
        }
        var hp = document.getElementById("hp").value;
        if (hp == '') {
            $.messager.show({ // show error message
                title: 'Error',
                msg: 'Data no.hp Belum Di isi.'
            });
            $('#hp').focus();
            exit;
        }
        var tanggal_lahir = document.getElementById("tanggal_lahir").value;
        if (tanggal_lahir == '') {
            $.messager.show({ // show error message
                title: 'Error',
                msg: 'Data Tanggal Lahir Belum Di isi.'
            });
            $('#tanggal_lahir').focus();
            exit;
        }
        $('#fm').form('submit', {
            url: '<?= XROOT ?>users/crud_import/',
            onSubmit: function() {
                return $(this).form('validate');
            },
            success: function(result) {
                var result = eval('(' + result + ')');
                if (result.errorMsg) {
                    $.messager.show({
                        title: 'Error',
                        msg: result.errorMsg
                    });
                } else {
                    $('#modal').modal('hide');
                    //  $('#dlg').dialog('close');      // close dialog atau modal popup
                    $('#dguser').datagrid('reload'); // reload the Vendor data
                    $.messager.show({
                        title: 'Success !',
                        msg: 'Berhasil'
                    });
                }
            }
        });
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function destroyuser() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            $.messager.confirm('Attention!', '<strong class="text-danger">Hati-hati Melakukan aksi ini,</strong><br> Apakah Anda Yakin Ingin Menghapus Users ini ?<br>Nama : ' + row.nama, function(r) {
                if (r) {
                    $.post("<?= XROOT ?>users/delete_import", {
                        id: row.id
                    }, function(result) {
                        if (result.success) {
                            $('#dguser').datagrid('reload'); // reload the Vendor data
                            $.messager.show({ // show error message
                                title: 'Success !',
                                msg: 'Berhasil Di Hapus'
                            });
                        } else {
                            $.messager.show({ // show error message
                                title: 'Error',
                                msg: result.errorMsg
                            });
                        }
                    }, 'json');
                }
            });
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function change_foto() {
        var row = $('#dguser').datagrid('getSelected');
        if (row) {
            document.getElementById("id").value = row.id;
            $('#foto').modal('show');
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    function show_foto(val, row) {
        for (var name in row) {
            if (row["foto"] == '') {
                var t = '<img src="<?= XROOT ?>img/avatar/' + row["jk"] + '.png" class="rounded elevation-2 m-1" width="34" alt="' + row["nama"] + '">';
            } else {
                var t = '<img src="<?= XROOT ?>img/avatar/' + row["foto"] + '" class="rounded elevation-2 m-1" width="34" alt="' + row["nama"] + '">';
            }
            if (row["pur_foto"] == "Received") {} else {
                return t;
            }
        }
    }
    //-----------------------------------------end
    //-----------------------------------------start
    $(function() {
        var base = '<?= base_url() ?>';
        $('#dguser').datagrid({
            data: '',
            singleSelect: true,
            onRowContextMenu: function(e, index, row) {
                $(this).datagrid('selectRow', index);
                e.preventDefault();
                $('#mm').menu('show', {
                    left: e.pageX,
                    top: e.pageY
                });
            },
            onDblClickRow: function() {
                update();
            },
            rowStyler: function(index, row) {
                if (row.status == 'false') {
                    return 'color:red;font-weight:bold;';
                }
            }
        })

    })
    //-----------------------------------------end
    $('#cont2').hide();
    $('#cont1').show();
    //==========================================================
    $('#foto').on('shown.bs.modal', function() {
        $('#cont2').hide();
        $('#cont1').show();
        $image_crop = $('#temp_foto').croppie({
            enableExif: true,
            viewport: {
                width: 300,
                height: 400,
                type: 'square'
            }, //circle 
            boundary: {
                width: 300,
                height: 400
            }
        });
        $('#temp_foto').hide();
    });
    $('#foto').on('hidden.bs.modal', function() {
        $('#temp_foto').croppie('destroy');
        $('#cont2').hide();
        $('#cont1').show();
    });
    // setInterval(function() {},1000);
    //==========================================================
    //==========================================================
    $('#upload_image').on('change', function() {
        $('#temp_foto').show();
        $('#cont1').hide();
        $('#cont2').show();
        var reader = new FileReader();
        reader.onload = function(event) {
            $image_crop.croppie('bind', {
                url: event.target.result
            }).then(function() {
                console.log('jQuery bind complete');
            });
        }
        reader.readAsDataURL(this.files[0]);
    });
    //==========================================================
    //==========================================================
    $('.crop_image').click(function(event) {
        var id = document.getElementById("id").value;
        $image_crop.croppie('result', {
            type: 'canvas',
            size: 'viewport'
        }).then(function(response) {
            $.ajax({
                url: "<?= XROOT ?>users/crop_img_import",
                type: "POST",
                data: {
                    "image": response,
                    "id": id
                },
                success: function(data) {
                    $('#foto').modal('hide');
                    $('#crop').modal('hide');
                    $('#dguser').datagrid('reload');
                    $.messager.show({ // show error message
                        title: 'Success !',
                        msg: 'Foto berhasil di ganti'
                    });
                }
            });
        });
    });
    //==========================================================
    $('#hp').on('keypress', function(event) {
        return (((event.which > 47) && (event.which < 58)) || (event.which == 13));
    });
</script>