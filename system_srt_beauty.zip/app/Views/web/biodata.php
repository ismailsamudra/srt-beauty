<link rel="stylesheet" href="<?= XROOT ?>script/crop/croppie.css">
<!-- TOP NAVIGASI START -->
<style>
    img {
        border-radius: 10%;
    }
</style>
<div class="card-header col-md-12 wid-t bg-1">
    <center>
        <small>
            <?php
            if (me() !== null) {
                echo '<a href="javascript:void(0);" onclick="history.back()" class="btn-sm bt-1 float-left mr-2" title="Back"><i class="fa fa-arrow-left"></i></a>';
            }
            ?>
            <h5><i class="fa fa-id-card mr-2"></i> <strong>BIODATA</strong>
                <a href="" class="btn-sm bt-1 float-right" title="RELOAD"><i class="fa fa-sync"></i></a>
            </h5>
        </small>
    </center>

</div>
<?php
$x = one('users', $id);
$o = one($x->level, $id);
$tb = $x->level . '_schema';
$foto = ($x->foto == null) ? $x->jk . '2.png' : $x->foto;
?>
<?php $rr = db($tb)->orderBy('row', 'ASC')->whereNotIn('id', ['akses'])->getWhere(['status' => 'true'])->getResult(); ?>
<!-- TOP NAVIGASI END -->
<!-- BODY START -->
<div class="container mt-4">
    <div class="row">
        <div class="col-12">
            <div class="row m-1">
                <div class="col-md-3">
                    <div class="row">
                        <div class="mb-2 col-md-12">
                            <div class="card-body">
                                <!-- <div class="container"> -->
                                <img src="<?= XROOT ?>img/avatar/<?= $foto ?>" width="100%">
                                <!-- </div> -->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-7">
                    <?php foreach ($rr as $r) : ?>
                        <?php
                        $id = $r->id;
                        $res = $o->$id;
                        if ($id == 'jk') {
                            $res = ($res == 'L') ? 'Laki-Laki' : $res = 'Perempuan';
                        }
                        if ($r->type == 'date') {
                            $res = date("d-m-Y", strtotime($o->$id));
                        }
                        ?>
                        <!-- BATAS GARIS 1 -->
                        <div class="row mb-1 mt-1">
                            <div class="col-md-4">
                                <div class="card table-responsive">
                                    <strong>&nbsp;&nbsp;<?= $r->label ?></strong>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="card table-responsive">
                                    &nbsp;&nbsp;<?= $res ?>
                                </div>
                            </div>
                        </div>
                        <!-- BATAS GARIS 1 -->
                    <?php endforeach ?>
                    <!-- BATAS GARIS 1 -->
                    <div class="row mb-1 mt-1">
                        <div class="col-md-4">
                            <div class="card table-responsive">
                                <strong>&nbsp;&nbsp;Level</strong>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="card table-responsive">
                                <strong>&nbsp;&nbsp;<?= level_n($x->level) ?></strong>
                            </div>
                        </div>
                    </div>
                    <!-- BATAS GARIS 1 -->
                    <!-- BATAS GARIS 1 -->
                    <div class="row mb-1 mt-1">
                        <div class="col-md-4">
                            <div class="card table-responsive">
                                <strong>&nbsp;&nbsp;Tgl Register</strong>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="card table-responsive">
                                <strong>&nbsp;&nbsp;<?= date("d M Y", strtotime($o->sort)); ?></strong>
                            </div>
                        </div>
                    </div>
                    <!-- BATAS GARIS 1 -->
                </div>
                <div class="col-md-2">
                    <center>
                        <a href="javascript:void(0);" onclick="d_qr();">
                            <small><strong>UNDUH QRCODE</strong></small>
                            <div id="qrcode"></div>
                        </a>
                    </center>
                </div>
            </div>


        </div>

    </div>
    <!-- BODY END -->
    <script src="<?= XROOT ?>script/qr-code-styling.js"></script>
    <script src="<?= XROOT ?>script/show_qr2.js"></script>
    <script>
        var data = "<?= XURL . 'biodata/' . $x->id ?>";
        var logo = "<?= XROOT ?>img/instansi/<?= inc('logo-n') ?>";
        var color = "<?= color('qrcode-a') ?>";
        qrcode("qrcode", data, logo, color, '0');

        function d_qr() {
            download_qrcode(data, logo, color);
        }
    </script>
    <script type="text/javascript">
        function manual() {
            $('#manual').modal('show');
        }
    </script>