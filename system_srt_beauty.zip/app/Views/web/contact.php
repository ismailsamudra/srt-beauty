<script src="<?= XROOT ?>script/web/js/jquery.min.js"></script>
<style>
    .dt:hover .wa,
    .dt:hover .arr,
    .dt:hover {
        background-color: <?= color('primary-a'); ?>;
        color: <?= color('primary-b'); ?>;

    }

    /* .dt:hover {
        color: <?= color('primary-b'); ?>;
    } */

    .wa {
        color: green;
    }

    .arr {
        color: <?= color('primary-a'); ?>;
    }
</style>
<!-- BODY START ----------------------------------------------------------->
<div class="col-md-12 my-4">
    <div class="full center">
        <div class="heading_main text_align_center">
            <h2><span class="theme_color">CONTACT</span> ADMIN</h2>
            <p class="large" id="label_top"><?= inc('app-name') ?></p>
        </div>
    </div>
</div>
<?php $contact = db('web_contact')->getWhere(['status' => 'true'])->getResult(); ?>
<!-- <div class="section layout_padding"> -->
<div class="container">
    <div class="row">
        <?php foreach ($contact as $o) : ?>
            <div class="col-12">
                <a href="<?= $o->url ?>" target="_blank">
                    <div class="card table-responsive dt col my-1">
                        <div class="row">
                            <div class="col-md-1 col-2">
                                <center>
                                    <i class="fab fa-whatsapp wa fa-2x my-1"></i>
                                </center>
                            </div>
                            <div class="col-10 mt-1">
                                <strong class=""><?= $o->label ?></strong>
                            </div>
                            <div class="col-md-1">
                                <center>
                                    <i class="fa fa-sign-in-alt arr fa-2x my-1 dt1"></i>
                                </center>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        <?php endforeach ?>

    </div>
</div>

<!-- </div> -->

<!-- BODY END ------------------------------------------------------------->

<br><br><br><br><br><br><br><br>