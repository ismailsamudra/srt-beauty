<!-- BODY START ----------------------------------------------------------->
<div class="col-md-12 my-4">
    <div class="full center">
        <div class="heading_main text_align_center">
            <h2><span class="theme_color">LINK</span>TERKAIT</h2>
            <p class="large"><?= inc('app-name') ?></p>
        </div>
    </div>
</div>
<style>
    .round {
        border-radius: 10px;
    }

    .bot {
        position: absolute;
        bottom: 0;
        left: 0;
    }

    .dt:hover .arr,
    .dt:hover {
        background-color: #dce2fc;
    }

    .arr {
        color: <?= color('primary-a'); ?>;
    }
</style>
<div class="section layout_padding">
    <div class="container">
        <?php $link = db('web_link')->orderBy('id', 'DESC')->getWhere(['status' => 'true'])->getResult(); ?>
        <?= (!$link) ? '<center><strong><br><br><br><br>NO CONTENT<br><br><br><br></strong></center>' : ''; ?>
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <?php foreach ($link as $o) : ?>
                        <?php $img = (empty($o->logo)) ? 'index.png' : $o->logo; ?>
                        <?php $href = (empty($o->url)) ? 'href="javascript:void(0);"' : 'href="' . $o->url . '" target="_blank"'; ?>
                        <div class="col-md-2 col-6 mb-2">
                            <a <?= $href ?>>
                                <div class="card col dt">
                                    <center>
                                        <img class="my-2" src="<?= XROOT ?>img/link/<?= $img ?>" title="<?= $o->nama ?>" width="100%" />
                                        <small><strong><?= $o->nama ?></strong></small>
                                    </center>
                                </div>
                            </a>
                        </div>

                    <?php endforeach ?>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- BODY END ------------------------------------------------------------->