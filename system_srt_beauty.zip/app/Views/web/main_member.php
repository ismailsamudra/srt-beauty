<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title><?= $title ?></title>
    <link rel="icon" type="image/x-icon" href="<?= XROOT ?>img/instansi/<?= inc('logo') ?>" />
    <link href="<?= XROOT ?>script/web2/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= XROOT ?>script/web2/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?= XROOT ?>script/web2/css/prettyPhoto.css" rel="stylesheet">
    <link href="<?= XROOT ?>script/web2/css/price-range.css" rel="stylesheet">
    <link href="<?= XROOT ?>script/web2/css/animate.css" rel="stylesheet">
    <link href="<?= XROOT ?>script/web2/css/main.css" rel="stylesheet">
    <link href="<?= XROOT ?>script/web2/css/responsive.css" rel="stylesheet">
    <?php
    echo view('part/web/css');
    ?>
</head>
<!--/head-->

<body>
    <!-- BODY START -->
    <div class="features_items">
        <!--features_items-->

        <?php foreach ($item as $x) : ?>
            <?php
            $foto = ($x->foto == null) ? $x->jk . '2.png' : $x->foto;
            ?>
            <div class="row">
                <div class="col-sm-2">
                    <div class="product-image-wrapper">
                        <div class="single-products">
                            <div class="productinfo text-center">
                                <img src="<?= XROOT ?>img/avatar/<?= $foto ?>" alt="" width="100" />

                            </div>

                        </div>

                    </div>
                </div>
                <div class="col-sm-10">
                    <div class="product-image-wrapper">
                        <div class="single-products">
                            <div class="productinfo">
                                <h4><?= $x->nama ?></h4>
                                <h5>Alamat : <?= $x->alamat ?></h5>
                                <h5>Kota / Kabupaten : <strong><?= $x->kota___kabupaten ?></strong></h5>
                                <a href="https://wa.me/<?= $x->hp ?>" class="btn btn-primary" target="_blank"><i class="fa fa-phone"></i> Whatsapp</a>
                                <a href="<?= XROOT ?>web/biodata/<?= $x->id ?>" class="btn btn-primary"><i class="fa fa-user"></i> Biodata</a>

                            </div>

                        </div>

                    </div>
                </div>
            </div>
        <?php endforeach ?>

    </div>
    <!--features_items-->

    <!-- BODY END -->
</body>
<script src="<?= XROOT ?>script/web2/js/jquery.js"></script>
<script src="<?= XROOT ?>script/web2/js/bootstrap.min.js"></script>
<script src="<?= XROOT ?>script/web2/js/jquery.scrollUp.min.js"></script>
<script src="<?= XROOT ?>script/web2/js/price-range.js"></script>
<script src="<?= XROOT ?>script/web2/js/jquery.prettyPhoto.js"></script>
<!-- <script src="<?= XROOT ?>script/web2/js/main.js"></script> -->
</body>

</html>
<!-- Modal -->
<div id="selengkapnya" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Modal Header</h4>
            </div>
            <div class="modal-body">
                <p>Some text in the modal.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>