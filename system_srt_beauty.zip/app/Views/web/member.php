<section id="slider">

    <!--slider-->
    <div class="container">
        <div class="row" hidden>
            <div class="col-sm-12">
                <div id="slider-carousel" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <li data-target="#slider-carousel" data-slide-to="0" class="active"></li>
                        <li data-target="#slider-carousel" data-slide-to="1"></li>
                        <li data-target="#slider-carousel" data-slide-to="2"></li>
                    </ol>

                    <div class="carousel-inner">

                    </div>

                    <a href="#slider-carousel" class="left control-carousel hidden-xs" data-slide="prev">
                        <i class="fa fa-angle-left"></i>
                    </a>
                    <a href="#slider-carousel" class="right control-carousel hidden-xs" data-slide="next">
                        <i class="fa fa-angle-right"></i>
                    </a>
                </div>

            </div>
        </div>
    </div>
</section>
<!--/slider-->
<div class="hr1"></div>
<section>
    <div class="container">
        <div class="row">
            <div class="col-sm-8"></div>
            <div class="col-sm-4">
                <div class="search_box">
                    <input type="text" id="cari" onkeyup="cari()" class="width:50%;" placeholder="Cari Nama Member / Kota ..." />
                </div>
            </div>
            <div class="col-sm-12 padding-right">
                <h2 class="title text-center">MEMBER LIST</h2>

                <script>
                    function resizeIframe(obj) {
                        obj.style.height = obj.contentWindow.document.body.scrollHeight + 'px';
                    }

                    function cari() {
                        var cari = document.getElementById('cari').value;
                        if (cari == '') {
                            document.getElementById('frame').src = '<?= XROOT ?>web/main_member';
                        } else {
                            document.getElementById('frame').src = '<?= XROOT ?>web/main_member/' + cari;
                        }
                    }
                </script>
                <iframe id="frame" src="<?= XROOT ?>web/main_member" width="100%" scrolling="no" onload="resizeIframe(this)" frameborder="0"></iframe>


            </div>

        </div>
    </div>
</section>