<section id="slider" class="slider">
    <div class="slider_overlay">
        <div class="container">
            <div class="row">
                <div class="main_slider text-center">
                    <div class="col-md-12">
                        <div class="main_slider_content wow zoomIn" data-wow-duration="1s">
                            <h1>Stifa Makassar</h1>
                            <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi. </p>
                            <button href="" class="btn-lg">Click here</button>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>


<section id="abouts" class="abouts">
    <div class="container">
        <div class="row">
            <div class="abouts_content">
                <div class="col-md-6">
                    <div class="single_abouts_text text-center wow slideInLeft" data-wow-duration="1s">
                        <img src="<?= XROOT ?>script/web2/images/melon.png" alt="" />
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="single_abouts_text wow slideInRight" data-wow-duration="1s">
                        <h4>Tentang Kami</h4>
                        <h3>WE ARE TASTY</h3>
                        <div style="color:black;">
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's stan</p>

                            <p>dard dummy text ever since the 1500s,when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesettingdard dummy text ever since the 1500s,when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting</p>
                        </div>

                        <!-- <a href="" class="btn btn-primary">click here</a> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="features" class="features">
    <div class="slider_overlay">
        <div class="container">
            <div class="row">
                <div class="main_features_content_area  wow fadeIn" data-wow-duration="3s">
                    <div class="col-md-12">
                        <div class="main_features_content text-left">
                            <div class="col-md-6">
                                <div class="single_features_text">
                                    <h4>Kegiatan Terbaru</h4>
                                    <h3>Taste of Precious</h3>
                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's stan</p>
                                    <p>dard dummy text ever since the 1500s,when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesettingdard dummy text ever since the 1500s,when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting</p>

                                    <a href="" class="btn btn-primary">click here</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="portfolio" class="portfolio">
    <div class="container">
        <div class="row">
            <div class="portfolio_content text-center  wow fadeIn" data-wow-duration="5s">
                <div class="col-md-12">
                    <div class="head_title text-center">
                        <h4>Produk Unggulan</h4>
                    </div>

                    <div class="main_portfolio_content">
                        <div class="col-md-3 col-sm-4 col-xs-6 single_portfolio_text">
                            <img src="<?= XROOT ?>script/web2/images/p1.png" alt="" />
                            <div class="portfolio_images_overlay text-center">
                                <h6>Italian Source Mushroom</h6>
                                <p class="product_price">Rp. 12.000</p>
                                <a href="" class="btn btn-primary">Click here</a>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-4 col-xs-6 single_portfolio_text">
                            <img src="<?= XROOT ?>script/web2/images/p2.png" alt="" />
                            <div class="portfolio_images_overlay text-center">
                                <h6>Italian Source Mushroom</h6>
                                <p class="product_price">Rp.15.000</p>
                                <a href="" class="btn btn-primary">Click here</a>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-4 col-xs-6 single_portfolio_text">
                            <img src="<?= XROOT ?>script/web2/images/p3.png" alt="" />
                            <div class="portfolio_images_overlay text-center">
                                <h6>Italian Source Mushroom</h6>
                                <p class="product_price">$12</p>
                                <a href="" class="btn btn-primary">Click here</a>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-4 col-xs-6 single_portfolio_text">
                            <img src="<?= XROOT ?>script/web2/images/p4.png" alt="" />
                            <div class="portfolio_images_overlay text-center">
                                <h6>Italian Source Mushroom</h6>
                                <p class="product_price">$12</p>
                                <a href="" class="btn btn-primary">Click here</a>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-4 col-xs-6 single_portfolio_text">
                            <img src="<?= XROOT ?>script/web2/images/p5.png" alt="" />
                            <div class="portfolio_images_overlay text-center">
                                <h6>Italian Source Mushroom</h6>
                                <p class="product_price">$12</p>
                                <a href="" class="btn btn-primary">Click here</a>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-4 col-xs-6 single_portfolio_text">
                            <img src="<?= XROOT ?>script/web2/images/p6.png" alt="" />
                            <div class="portfolio_images_overlay text-center">
                                <h6>Italian Source Mushroom</h6>
                                <p class="product_price">$12</p>
                                <a href="" class="btn btn-primary">Click here</a>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-4 col-xs-6 single_portfolio_text">
                            <img src="<?= XROOT ?>script/web2/images/p7.png" alt="" />
                            <div class="portfolio_images_overlay text-center">
                                <h6>Italian Source Mushroom</h6>
                                <p class="product_price">$12</p>
                                <a href="" class="btn btn-primary">Click here</a>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-4 col-xs-6 single_portfolio_text">
                            <img src="<?= XROOT ?>script/web2/images/p8.png" alt="" />
                            <div class="portfolio_images_overlay text-center">
                                <h6>Italian Source Mushroom</h6>
                                <p class="product_price">$12</p>
                                <a href="" class="btn btn-primary">Click here</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="footer_widget" class="footer_widget">
    <div class="container">
        <div class="row">
            <div class="footer_widget_content text-center">
                <div class="col-md-4">
                    <div class="single_widget wow fadeIn" data-wow-duration="2s">
                        <h3>Alamat</h3>

                        <div class="single_widget_info">
                            <p>Jl Makassar No.00
                            </p>
                        </div>

                        <div class="footer_socail_icon">
                            <a href=""><i class="fa fa-facebook"></i></a>
                            <a href=""><i class="fa fa-instagram"></i></a>
                            <a href=""><i class="fa fa-whatsapp"></i></a>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="single_widget wow fadeIn" data-wow-duration="4s">
                        <h3>Email</h3>

                        <div class="single_widget_info">
                            <p><span class="date_day">admin@admin.com</span>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="single_widget wow fadeIn" data-wow-duration="5s">
                        <h3>Telp / Fax</h3>
                        <div class="single_widget_info">
                            <p><span class="date_day">08313624xxxx</span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>